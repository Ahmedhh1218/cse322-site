Put your report here as report.pdf (export it from Word or LaTeX as a text PDF, not scanned pages).
It must contain: the contribution of each team member, flowcharts of the main program flow,
the list of components and the wiring diagrams, photos of the prototype, and problems faced with their solutions.
An automated check looks for these sections and for at least 3 pictures.
