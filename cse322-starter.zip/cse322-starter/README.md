# CSE322 Home Appliances Control: team repository

Read `docs/Project_Description.pdf` first (requirements, pin map, protocol, grading).

## Layout
| Folder | What goes there |
|---|---|
| `firmware/mcal/` | register-level drivers (GPIO, ADC, UART, SysTick) |
| `firmware/hal/`  | `hal.h` (fixed contract) and your `hal.c` on top of the MCAL |
| `firmware/app/`  | the application: protocol, alarm, door events. Only `hal.h` + standard C |
| `mobile-app/`    | the mobile app project (source only) |
| `report/`        | `report.pdf` |
| `TEAM.md`        | members, contributions, link to the 5-minute demo video |

## How to submit
1. Develop on the real board, commit often. Every member must commit (commit history is used to adjust individual marks).
2. Every push runs the checks on GitHub (Actions tab). You can run the same checks on your PC:
   ```
   python3 tools/check_submission.py   # structure and layer rules
   make test                           # protocol tests on a simulated board (needs gcc)
   ```
3. When everything is green, push a tag to get the file to hand in:
   ```
   git tag final-1 && git push origin final-1
   ```
   Download `submission.zip` from the Actions run and upload it on the course site before the Week 13 deadline.

The automated check covers the board side of the protocol only. The video, the app, mounting and the report are marked by the instructors.
