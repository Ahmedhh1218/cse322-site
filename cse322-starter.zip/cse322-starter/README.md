# CSE322 Home Appliances Control: team repository

Read `docs/Project_Description.pdf` first (requirements, pin map, Bluetooth protocol).

The board talks to your phone app through an **HC-05 Bluetooth module** on UART1 (PB0/PB1, 9600 baud), with the text lines of the Bluetooth protocol.

## Layout
| Folder | What goes there |
|---|---|
| `firmware/mcal/` | your drivers, any files and structure you like, on registers or TivaWare |
| `firmware/hal/`  | the six device headers are given (`lamp.h`, `plug.h`, `door.h`, `lm35.h`, `serial.h`, `timebase.h`, do not change them); write the `.c` files as you like, on top of your MCAL |
| `firmware/app/`  | the board application: Bluetooth protocol, alarm. Only the six HAL headers + standard C |
| `mobile-app/`    | your phone app (App Inventor `.aia` export, or any framework's source): lamp, plug, door, temperature, limit, alert, door log |
| `report/`        | `report.pdf` |
| `TEAM.md`        | members, contributions, link to the 5-minute demo video |

## Check your work
```
make grade          # the marks the automated check gives you (needs gcc, python3; arm-none-eabi-gcc and poppler-utils for the full check;
                    # pip install unicorn pyelftools for the emulator)
make emu            # runs your built Debug/Exe/*.out (from IAR) on an emulated TM4C123 with an HC-05 and lists failing tests
make app-check      # static check of mobile-app/ against the protocol
make test           # only the protocol tests, shows which test fails
make hw-check       # MCAL / HAL static checks and the ARM cross-compile
make report-check   # report structure check
```
Every push also runs these on GitHub (Actions tab). The final marks come from the same checks run on the file you upload.

## How to submit
1. Develop on the real board in IAR. Every member must contribute.
2. Build the project again in IAR (Project > Rebuild All), so the image `Debug/Exe/<name>.out` matches your sources.
3. Zip your **whole project folder** (sources, `mobile-app/`, report, `TEAM.md`, project files and the built `.out`) and upload it on the course submission page before the Week 13 deadline. The page checks the zip in your browser first.

The grader runs your sources on a simulated board and your `.out` on an emulated TM4C123 with an HC-05 (both must pass for the board part of each mark), and checks your phone app against the protocol (the other part). The emulator catches wrong pins, a wrong baud rate and missing peripheral clocks, but it cannot see your wiring, so test on the real board and show it in your demo video.


