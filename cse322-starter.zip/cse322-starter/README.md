# CSE322 Home Appliances Control: team repository

Read `docs/Project_Description.pdf` first (requirements, pin map, terminal protocol, grading).

You control the board from a PC with **PuTTY** over the LaunchPad's USB cable (UART0, 115200 baud).

## Layout
| Folder | What goes there |
|---|---|
| `firmware/mcal/` | your drivers, any files and structure you like, on registers or TivaWare |
| `firmware/hal/`  | the six device headers are given (`lamp.h`, `plug.h`, `door.h`, `lm35.h`, `serial.h`, `timebase.h`, do not change them); write the `.c` files as you like, on top of your MCAL |
| `firmware/app/`  | the application: terminal protocol, alarm, door log. Only the six HAL headers + standard C |
| `report/`        | `report.pdf` |
| `TEAM.md`        | members, contributions, link to the 5-minute demo video |

## Check your work
```
make grade          # the marks the automated check gives you (needs gcc, python3; arm-none-eabi-gcc and poppler-utils for the full check)
make test           # only the protocol tests, shows which test fails
make hw-check       # MCAL / HAL static checks and the ARM cross-compile
make report-check   # report structure check
```
Every push also runs these on GitHub (Actions tab). The final marks come from the same checks run on the file you upload.

## How to submit
1. Develop on the real board, commit often. Every member must commit.
2. When everything is green, push a tag to get the file to hand in:
   ```
   git tag final-1 && git push origin final-1
   ```
   Download `submission.zip` from the Actions run and upload it on the course submission page before the Week 13 deadline.

The tests use a simulated board, so they cannot see wrong pin numbers or wiring. Test on the real board and show it in your demo video.
