#include "hal/lamp.h"
#include "hal/plug.h"
#include "hal/door.h"
#include "hal/lm35.h"
#include "hal/serial.h"
#include "hal/timebase.h"
#include "app/app.h"

int main(void)
{
    Time_Init(); Lamp_Init(); Plug_Init(); Door_Init(); Lm35_Init(); Serial_Init();
    App_Init();
    for (;;) App_Update();
}
