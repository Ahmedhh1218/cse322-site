#include "hal/hal.h"
#include "app/app.h"

int main(void)
{
    Hal_Init();
    App_Init();
    for (;;) App_Update();
}
