/* HAL contract for the time base -- DO NOT CHANGE THE SIGNATURES.
 * Implement them in timebase.c on top of your MCAL (or TivaWare), for example with SysTick. */
#ifndef TIMEBASE_H
#define TIMEBASE_H
#include <stdint.h>
void     Time_Init(void);               /* start a 1 ms tick                 */
uint32_t Time_Millis(void);             /* milliseconds since boot           */
#endif
