/* TODO (team): implement every function declared in serial.h using your MCAL (or TivaWare). */
#include "serial.h"
