/* HAL contract for the lamp relay -- DO NOT CHANGE THE SIGNATURES.
 * Implement them in lamp.c on top of your MCAL (or TivaWare). */
#ifndef LAMP_H
#define LAMP_H
void Lamp_Init(void);          /* PA2 as output, lamp off                  */
void Lamp_Set(int on);         /* PA2 -> lamp relay IN (1 = lamp on)       */
#endif
