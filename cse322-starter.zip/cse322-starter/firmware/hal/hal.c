/* TODO (team): implement every function declared in hal.h for the TM4C123GH6PM,
 * using your MCAL drivers from ../mcal. */
#include "hal.h"
