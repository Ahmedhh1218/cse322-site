/* TODO (team): implement every function declared in door.h using your MCAL (or TivaWare). */
#include "door.h"
