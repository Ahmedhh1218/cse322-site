/* TODO (team): implement every function declared in lm35.h using your MCAL (or TivaWare). */
#include "lm35.h"
