/* TODO (team): implement every function declared in timebase.h using your MCAL (or TivaWare). */
#include "timebase.h"
