/* TODO (team): implement every function declared in lamp.h using your MCAL (or TivaWare). */
#include "lamp.h"
