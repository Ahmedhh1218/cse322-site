/* TODO (team): implement every function declared in plug.h using your MCAL (or TivaWare). */
#include "plug.h"
