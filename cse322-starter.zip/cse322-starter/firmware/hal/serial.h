/* HAL contract for the Bluetooth link (HC-05 on UART1).
 * DO NOT CHANGE THE SIGNATURES. Implement them in serial.c on top of your MCAL (or TivaWare). */
#ifndef SERIAL_H
#define SERIAL_H
void Serial_Init(void);                 /* UART1 on PB0 (Rx) / PB1 (Tx), 9600 8N1 */
int  Serial_Read(void);                 /* next received byte, or -1 if none */
void Serial_Write(const char *s);       /* send a NUL-terminated string      */
#endif
