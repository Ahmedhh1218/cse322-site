/* HAL contract for the terminal link (UART0 = USB virtual COM port, PuTTY).
 * DO NOT CHANGE THE SIGNATURES. Implement them in serial.c on top of your MCAL (or TivaWare). */
#ifndef SERIAL_H
#define SERIAL_H
void Serial_Init(void);                 /* UART0 on PA0/PA1, 115200 8N1     */
int  Serial_Read(void);                 /* next received byte, or -1 if none */
void Serial_Write(const char *s);       /* send a NUL-terminated string      */
#endif
