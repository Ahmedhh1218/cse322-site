/* HAL contract for the door switch (magnetic door switch on PA4, pull-up, low = closed) -- DO NOT CHANGE THE SIGNATURES.
 * Implement them in door.c on top of your MCAL (or TivaWare). */
#ifndef DOOR_H
#define DOOR_H
void Door_Init(void);          /* PA4 as input with pull-up                */
int  Door_IsOpen(void);        /* PA4: low = closed, high = open           */
#endif
