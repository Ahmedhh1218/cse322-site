/* HAL contract for the plug relay -- DO NOT CHANGE THE SIGNATURES.
 * Implement them in plug.c on top of your MCAL (or TivaWare). */
#ifndef PLUG_H
#define PLUG_H
void Plug_Init(void);          /* PA3 as output, plug off                  */
void Plug_Set(int on);         /* PA3 -> plug relay IN (1 = plug powered)  */
#endif
