/* HAL contract -- DO NOT CHANGE THE SIGNATURES.
 * The app layer talks to the hardware only through these functions.
 * Implement them in hal.c on top of your MCAL (GPIO, ADC, UART0, SysTick).
 * The automated tests replace hal.c with a simulated board, so the app layer
 * must run on a PC without any TM4C header. */
#ifndef HAL_H
#define HAL_H
#include <stdint.h>

void     Hal_Init(void);              /* clocks, pins, ADC, UART0 115200 8N1, SysTick  */
void     Hal_LampSet(int on);         /* PA2 -> lamp relay IN   (1 = lamp on)         */
void     Hal_PlugSet(int on);         /* PA3 -> plug relay IN   (1 = plug powered)    */
int      Hal_DoorIsOpen(void);        /* PA4, pull-up: low = closed, high = open      */
int      Hal_TempReadDeciC(void);     /* PE3 / LM35, tenths of a degree C (275=27.5)  */
int      Hal_UartRead(void);          /* UART0 (PA0 U0Rx): next byte, or -1 if none   */
void     Hal_UartWrite(const char *s);/* UART0 (PA1 U0Tx): send a NUL-terminated string*/
uint32_t Hal_Millis(void);            /* milliseconds since boot                      */
#endif
