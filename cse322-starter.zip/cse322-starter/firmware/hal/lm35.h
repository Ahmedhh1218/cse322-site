/* HAL contract for the LM35 temperature sensor -- DO NOT CHANGE THE SIGNATURES.
 * Implement them in lm35.c on top of your MCAL (or TivaWare). */
#ifndef LM35_H
#define LM35_H
void Lm35_Init(void);          /* PE3 / AIN0 and the ADC                   */
int  Lm35_ReadDeciC(void);     /* tenths of a degree C (275 = 27.5 C)      */
#endif
