/* TODO (team): MCAL driver declarations */
