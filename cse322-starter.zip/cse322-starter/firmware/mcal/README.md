Put your register-level drivers here (GPIO, ADC, UART0, SysTick) as .c/.h files.
Only the HAL may include these. The app layer must not.
Keep every header your drivers need inside firmware/ (for example your tm4c123gh6pm.h) so the check can compile your code.
