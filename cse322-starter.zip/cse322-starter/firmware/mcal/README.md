Put your register-level drivers here as separate modules: for example dio.c/.h (GPIO), uart.c/.h, adc.c/.h, systick.c/.h.
You may build them on TivaWare (driverlib) instead of raw registers: copy the driverlib files you use into this folder,
or write thin wrappers around the TivaWare calls.
Only the HAL may include these. The app layer must not.
Keep every header your drivers need inside firmware/ so the automatic check can compile your code.
