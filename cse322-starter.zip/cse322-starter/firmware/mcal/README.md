Put your drivers here: any files and structure you like (for example dio, uart, adc, systick modules), written on the registers or on TivaWare.
If you use TivaWare, copy the driverlib files you use into firmware/ or write thin wrappers around the calls.
Only the HAL may include these. The app layer must not.
Keep every header your drivers need inside firmware/ so the automatic check can compile your code.
