Put your register-level drivers here (GPIO, ADC, UART, SysTick) as .c/.h files.
Only the HAL may include these. The app layer must not.
