/* TODO (team): implement the protocol from docs/Project_Description.pdf.
 * Use only hal.h (../hal/hal.h) and the C standard library. No TM4C headers. */
#include "app.h"
#include "../hal/hal.h"

void App_Init(void)   { }
void App_Update(void) { }
