/* TODO (team): implement the protocol from docs/Project_Description.pdf.
 * Use only the HAL headers (lamp.h, plug.h, door.h, lm35.h, serial.h, timebase.h) and the C standard library.
 * No TM4C headers. */
#include "app.h"
#include "../hal/lamp.h"
#include "../hal/plug.h"
#include "../hal/door.h"
#include "../hal/lm35.h"
#include "../hal/serial.h"
#include "../hal/timebase.h"

void App_Init(void)   { }
void App_Update(void) { }
