#ifndef APP_H
#define APP_H
void App_Init(void);    /* call once after Hal_Init()            */
void App_Update(void);  /* call forever from main(): non-blocking */
#endif
