#!/usr/bin/env python3
"""Structure check of report/report.pdf: it only looks for the required sections and enough pictures.
It does NOT judge the quality of the report. Usage: check_report.py [ROOT] [out.json]"""
import json, os, re, shutil, subprocess, sys

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else "."
OUT = sys.argv[2] if len(sys.argv) > 2 else None
pdf = os.path.join(ROOT, "report", "report.pdf")
checks = []
def add(title, ok, hint=""): checks.append({"title": title, "ok": bool(ok), "skipped": False, "hint": hint})
def run(*a):
    try: return subprocess.run(a, capture_output=True, text=True, timeout=60).stdout
    except Exception: return ""

valid = os.path.isfile(pdf) and open(pdf, "rb").read(5) == b"%PDF-"
text, pages, images = "", 0, 0
if valid and shutil.which("pdftotext"):
    text = run("pdftotext", "-layout", pdf, "-").lower()
    m = re.search(r"^Pages:\s+(\d+)", run("pdfinfo", pdf), re.M); pages = int(m.group(1)) if m else 0
    images = max(0, len(run("pdfimages", "-list", pdf).splitlines()) - 2)
add("report.pdf is a readable PDF with at least 4 pages", valid and pages >= 4, "%d pages" % pages if valid else "")
add("Lists the contribution of each team member", "contribution" in text)
add("Has flowcharts of the main program flow", re.search(r"flow ?chart", text) is not None)
add("Lists the components and wiring diagrams", "component" in text and re.search(r"wiring|connection diagram|schematic", text) is not None)
add("Shows photos of the prototype", re.search(r"photo|picture", text) is not None)
add("Describes problems faced and solutions", "problem" in text)
add("Has at least 3 pictures (diagrams, photos)", images >= 3, "%d pictures found" % images)

res = {"passed": sum(c["ok"] for c in checks), "total": len(checks), "checks": checks}
if OUT: json.dump(res, open(OUT, "w"), indent=2)
for c in checks: print("ok  " if c["ok"] else "FAIL", c["title"], ("- " + c["hint"]) if c["hint"] else "")
print("REPORT CHECK: %d/%d" % (res["passed"], res["total"]))
