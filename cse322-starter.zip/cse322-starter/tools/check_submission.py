#!/usr/bin/env python3
"""Checks that a team repo is complete and follows the project rules.
Exit code 0 = all checks pass. Run:  python3 tools/check_submission.py"""
import os, re, sys

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
problems, notes = [], []

def p(*a): return os.path.join(ROOT, *a)
def read(path):
    with open(path, encoding="utf-8", errors="replace") as f: return f.read()
def code_files(d, exts=(".c", ".h")):
    out = []
    for base, _, files in os.walk(p(d)):
        out += [os.path.join(base, f) for f in files if f.endswith(exts)]
    return out
def fail(msg): problems.append(msg)

# 1. TEAM.md ---------------------------------------------------------------
if not os.path.isfile(p("TEAM.md")):
    fail("TEAM.md is missing")
else:
    t = read(p("TEAM.md"))
    if "TODO" in t: fail("TEAM.md still contains TODO placeholders")
    rows = [r for r in t.splitlines() if r.startswith("|")][2:]   # skip header + separator
    members = [r for r in rows if len([c for c in r.strip("|").split("|") if c.strip()]) >= 3]
    if not 4 <= len(members) <= 6:
        fail(f"TEAM.md lists {len(members)} members with a contribution; teams have 4 to 6")
    m = re.search(r"Demo video link:\s*(\S+)", t)
    if not m or not m.group(1).lower().startswith("http"):
        fail("TEAM.md needs 'Demo video link: https://...' (video is not stored in git)")

# 2. Firmware layers ---------------------------------------------------------
for layer in ("mcal", "hal", "app"):
    files = code_files(os.path.join("firmware", layer))
    if not files: fail(f"firmware/{layer}/ has no .c/.h files")
if not os.path.isfile(p("firmware", "hal", "hal.h")): fail("firmware/hal/hal.h (the HAL contract) is missing")
else:
    for fn in ("Hal_Init", "Hal_LampSet", "Hal_PlugSet", "Hal_DoorIsOpen", "Hal_TempReadDeciC",
               "Hal_UartRead", "Hal_UartWrite", "Hal_Millis"):
        if fn not in read(p("firmware", "hal", "hal.h")): fail(f"hal.h no longer declares {fn}")

# Layer rules: app must not touch hardware or MCAL; hal must not call app.
hw = re.compile(r'tm4c123|TM4C123|inc/hw_|driverlib|\bGPIO_PORT\w*|\bSYSCTL_\w+|\bNVIC_\w+|0x[4E][0-9A-Fa-f]{7}')
for f in code_files(os.path.join("firmware", "app")):
    txt = read(f); rel = os.path.relpath(f, ROOT)
    if hw.search(txt): fail(f"{rel}: the app layer must not use TM4C registers or headers")
    if re.search(r'#include\s+"[^"]*mcal[^"]*"', txt): fail(f"{rel}: the app layer must not include MCAL")
for f in code_files(os.path.join("firmware", "hal")):
    if re.search(r'#include\s+"[^"]*app[^"]*"', read(f)): fail(f"{os.path.relpath(f, ROOT)}: the HAL must not include the app layer")

# 3. Mobile app and report -----------------------------------------------------
ma = [f for _, _, fs in os.walk(p("mobile-app")) for f in fs if f != "README.md"]
if not ma: fail("mobile-app/ contains only the README: add the app project")
rep = p("report", "report.pdf")
if not os.path.isfile(rep): fail("report/report.pdf is missing")
else:
    with open(rep, "rb") as f:
        if f.read(5) != b"%PDF-": fail("report/report.pdf is not a PDF file")
    if os.path.getsize(rep) > 40 * 1024 * 1024: fail("report/report.pdf is bigger than 40 MB")

# 4. Repo hygiene -------------------------------------------------------------
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in (".git", "build")]
    for f in files:
        fp = os.path.join(base, f)
        if os.path.getsize(fp) > 50 * 1024 * 1024:
            fail(f"{os.path.relpath(fp, ROOT)} is larger than 50 MB (do not commit videos or build output)")
        if f.endswith((".mp4", ".mov", ".avi", ".mkv")):
            fail(f"{os.path.relpath(fp, ROOT)}: videos go in the link in TEAM.md, not in the repo")

if problems:
    print("SUBMISSION CHECK: FAILED")
    for x in problems: print(" -", x)
    sys.exit(1)
print("SUBMISSION CHECK: OK")
