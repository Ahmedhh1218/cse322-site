#!/usr/bin/env python3
"""Checks that a team repo is complete and follows the project rules.
Exit code 0 = all checks pass. Run:  python3 tools/check_submission.py"""
import os, re, sys

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
problems, notes = [], []

def p(*a): return os.path.join(ROOT, *a)
def read(path):
    with open(path, encoding="utf-8", errors="replace") as f: return f.read()
def code_files(d, exts=(".c", ".h")):
    out = []
    for base, _, files in os.walk(p(d)):
        out += [os.path.join(base, f) for f in files if f.endswith(exts)]
    return out
def fail(msg): problems.append(msg)

# 1. TEAM.md ---------------------------------------------------------------
if not os.path.isfile(p("TEAM.md")):
    fail("TEAM.md is missing")
else:
    t = read(p("TEAM.md"))
    if "TODO" in t: fail("TEAM.md still contains TODO placeholders")
    rows = [r for r in t.splitlines() if r.startswith("|")][2:]   # skip header + separator
    members = [r for r in rows if len([c for c in r.strip("|").split("|") if c.strip()]) >= 3]
    if not 4 <= len(members) <= 6:
        fail(f"TEAM.md lists {len(members)} members with a contribution; teams have 4 to 6")
    m = re.search(r"Demo video link:\s*(\S+)", t)
    if not m or not m.group(1).lower().startswith("http"):
        fail("TEAM.md needs 'Demo video link: https://...' (video is not stored in git)")

# 2. Firmware layers ---------------------------------------------------------
for layer in ("mcal", "hal", "app"):
    files = code_files(os.path.join("firmware", layer))
    if not files: fail(f"firmware/{layer}/ has no .c/.h files")
HAL_CONTRACT = {"lamp": ("Lamp_Init", "Lamp_Set"), "plug": ("Plug_Init", "Plug_Set"), "door": ("Door_Init", "Door_IsOpen"),
                "lm35": ("Lm35_Init", "Lm35_ReadDeciC"), "serial": ("Serial_Init", "Serial_Read", "Serial_Write"),
                "timebase": ("Time_Init", "Time_Millis")}
for mod, fns in HAL_CONTRACT.items():
    hp = p("firmware", "hal", mod + ".h")
    if not os.path.isfile(hp): fail(f"firmware/hal/{mod}.h (HAL contract) is missing")
    else:
        for fn in fns:
            if fn not in read(hp): fail(f"{mod}.h no longer declares {fn}")

# Layer rules: app must not touch hardware or MCAL; hal must not call app.
hw = re.compile(r'tm4c123|TM4C123|inc/hw_|driverlib|\bGPIO_PORT\w*|\bSYSCTL_\w+|\bNVIC_\w+|0x[4E][0-9A-Fa-f]{7}')
for f in code_files(os.path.join("firmware", "app")):
    txt = read(f); rel = os.path.relpath(f, ROOT)
    if hw.search(txt): fail(f"{rel}: the app layer must not use TM4C registers or headers")
    mcal_h = {os.path.basename(x) for x in code_files(os.path.join("firmware", "mcal"), (".h",))}
    incs = re.findall(r'#include\s+[<"]([^>"]+)[>"]', txt)
    if any("mcal" in i or os.path.basename(i) in mcal_h for i in incs): fail(f"{rel}: the app layer must not include MCAL")
for f in code_files(os.path.join("firmware", "hal")):
    if re.search(r'#include\s+"[^"]*app[^"]*"', read(f)): fail(f"{os.path.relpath(f, ROOT)}: the HAL must not include the app layer")

# 3. Report ---------------------------------------------------------------------
rep = p("report", "report.pdf")
if not os.path.isfile(rep): fail("report/report.pdf is missing")
else:
    with open(rep, "rb") as f:
        if f.read(5) != b"%PDF-": fail("report/report.pdf is not a PDF file")
    if os.path.getsize(rep) > 40 * 1024 * 1024: fail("report/report.pdf is bigger than 40 MB")

# 4. Repo hygiene -------------------------------------------------------------
for base, dirs, files in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in (".git", "build")]
    for f in files:
        fp = os.path.join(base, f)
        if os.path.getsize(fp) > 50 * 1024 * 1024:
            fail(f"{os.path.relpath(fp, ROOT)} is larger than 50 MB (do not commit videos or build output)")
        if f.endswith((".mp4", ".mov", ".avi", ".mkv")):
            fail(f"{os.path.relpath(fp, ROOT)}: videos go in the link in TEAM.md, not in the repo")

# Layered-architecture verdict: rules respected AND real code in every layer.
def code_lines(d):
    n = 0
    for f in code_files(d):
        for l in read(f).splitlines():
            l = l.strip()
            if l and not l.startswith(("//", "/*", "*", "#include")): n += 1
    return n
layer_lines = {l: code_lines(os.path.join("firmware", l)) for l in ("mcal", "hal", "app")}
layer_rule_problems = [x for x in problems if "must not" in x]
layers_ok = not layer_rule_problems and layer_lines["mcal"] >= 15 and layer_lines["hal"] >= 15 and layer_lines["app"] >= 30
if len(sys.argv) > 2:
    import json
    json.dump({"layers_ok": layers_ok, "layer_code_lines": layer_lines, "problems": problems}, open(sys.argv[2], "w"), indent=2)

if problems:
    print("SUBMISSION CHECK: FAILED")
    for x in problems: print(" -", x)
    sys.exit(1)
print("SUBMISSION CHECK: OK")
