#!/usr/bin/env python3
"""Static check of the mobile app against the project's protocol.

Works on an App Inventor export (mobile-app/*.aia: reads the blocks and the components) and, as a fallback, on
text source code of any other framework (looks for the protocol strings). Prints a checklist and writes JSON.

  python3 tools/check_app.py [project-folder] [out.json]

It proves that the app is built to speak the protocol; it cannot prove that it behaves correctly on a phone.
Blocks that are disabled, or that sit outside any event or procedure (they never run), are ignored.
"""
import glob, json, os, re, sys, zipfile
import xml.etree.ElementTree as ET

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = sys.argv[2] if len(sys.argv) > 2 else None
RUNNABLE_TOP = {"component_event", "global_declaration", "procedures_defnoreturn", "procedures_defreturn"}

def strip_ns(tag): return tag.split("}", 1)[-1]

class Facts:
    def __init__(self):
        self.texts, self.methods, self.events, self.setters = [], set(), set(), set()
        self.types, self.props, self.block_types = set(), {}, set()
    def has_text(self, s): return any(s in t for t in self.texts)
    def method(self, *names): return any((t, m) in self.methods for t, m in names)

def walk_blocks(el, facts):
    for child in el:
        if strip_ns(child.tag) != "block": continue
        if child.get("disabled") == "true": continue
        visit(child, facts)

def visit(block, facts):
    btype = block.get("type", "")
    facts.block_types.add(btype)
    mut = next((c for c in block if strip_ns(c.tag) == "mutation"), None)
    if btype == "text":
        for f in block:
            if strip_ns(f.tag) == "field" and f.get("name") == "TEXT": facts.texts.append(f.text or "")
    elif btype == "component_method" and mut is not None:
        facts.methods.add((mut.get("component_type"), mut.get("method_name")))
    elif btype == "component_event" and mut is not None:
        facts.events.add((mut.get("component_type"), mut.get("event_name")))
    elif btype == "component_set_get" and mut is not None and mut.get("set_or_get") == "set":
        facts.setters.add((mut.get("component_type"), mut.get("property_name")))
    for child in block:
        tag = strip_ns(child.tag)
        if tag in ("value", "statement", "next"):
            walk_blocks(child, facts)

def collect_components(node, facts):
    for c in node.get("$Components", []):
        facts.types.add(c.get("$Type"))
        facts.props.setdefault(c.get("$Type"), []).append(c)
        collect_components(c, facts)

def read_aia(path):
    facts = Facts()
    with zipfile.ZipFile(path) as z:
        screens = [n for n in z.namelist() if n.endswith(".scm")]
        if not screens: raise ValueError("no screens found in the .aia")
        for n in z.namelist():
            if n.endswith(".bky"):
                root = ET.fromstring(z.read(n))
                for top in root:
                    if strip_ns(top.tag) == "block" and top.get("type") in RUNNABLE_TOP and top.get("disabled") != "true":
                        visit(top, facts)
        for n in screens:
            raw = z.read(n).decode("utf-8", "replace")
            body = "\n".join(l for l in raw.splitlines() if l.strip() not in ("#|", "$JSON", "|#"))
            form = json.loads(body)["Properties"]
            facts.types.add(form.get("$Type")); collect_components(form, facts)
    return facts

def clock_ok(facts):
    clocks = facts.props.get("Clock", [])
    if not clocks: return False
    ok_timer = any(("Clock", "Timer") in facts.events for _ in [0])
    fast = any(int(c.get("TimerInterval", "1000") or 1000) <= 1000 and c.get("TimerEnabled", "True") != "False" for c in clocks) \
           or ("Clock", "TimerInterval") in facts.setters or ("Clock", "TimerEnabled") in facts.setters
    return ok_timer and fast

STORE = [("TinyDB", "StoreValue"), ("TinyWebDB", "StoreValue"), ("CloudDB", "StoreValue"), ("File", "AppendToFile"), ("File", "SaveFile")]
ALERT = [("Notifier", "ShowAlert"), ("Notifier", "ShowMessageDialog"), ("Notifier", "ShowTextDialog"), ("Notifier", "ShowChooseDialog"),
         ("Player", "Start"), ("Player", "Vibrate"), ("Sound", "Play"), ("Sound", "Vibrate")]
SEND = [("BluetoothClient", "SendText"), ("BluetoothClient", "Send1ByteNumber")]
RECV = [("BluetoothClient", "ReceiveText"), ("BluetoothClient", "BytesAvailableToReceive")]
CONN = [("BluetoothClient", "Connect"), ("BluetoothClient", "ConnectWithUUID")]
TIME = [("Clock", "Now"), ("Clock", "FormatDateTime"), ("Clock", "FormatTime"), ("Clock", "MakeInstant")]

def checks_for_aia(f):
    shows_door = any(p in f.setters for p in [("Label", "Text"), ("Image", "Picture"), ("Label", "TextColor"), ("Label", "BackgroundColor"), ("Button", "Text")])
    shows_list = any(p in f.setters for p in [("ListView", "Elements"), ("ListView", "ElementsFromString"), ("Label", "Text")])
    return {
      "lamp": [
        ("lamp_ui", "Has a control for the lamp (button, switch or checkbox)", bool(f.types & {"Button", "Switch", "CheckBox"})),
        ("lamp_send", "Sends LAMP:1 / LAMP:0 over Bluetooth", f.has_text("LAMP:") and f.method(*SEND)),
      ],
      "plug": [
        ("plug_ui", "Has a control for the plug", len(f.types & {"Button", "Switch", "CheckBox"}) > 0 and (f.has_text("PLUG:"))),
        ("plug_send", "Sends PLUG:1 / PLUG:0 over Bluetooth", f.has_text("PLUG:") and f.method(*SEND)),
      ],
      "door": [
        ("door_parse", "Reads DOOR:OPEN / DOOR:CLOSED messages", f.has_text("DOOR:") or (f.has_text("OPEN") and f.has_text("CLOSED"))),
        ("door_show", "Shows the door state on the screen", shows_door),
      ],
      "temp": [
        ("temp_poll", "A Clock timer polls the board about once per second", clock_ok(f)),
        ("temp_recv", "Receives text from the Bluetooth client", f.method(*RECV)),
        ("temp_parse", "Reads TEMP: messages", f.has_text("TEMP:")),
        ("temp_show", "Shows the temperature in a label", ("Label", "Text") in f.setters),
      ],
      "alarm": [
        ("alarm_limit", "Sends LIMIT:<n> to set the temperature limit", f.has_text("LIMIT:") and f.method(*SEND)),
        ("alarm_parse", "Reads ALARM: messages", f.has_text("ALARM:")),
        ("alarm_alert", "Shows an alert (notifier, sound or vibration)", f.method(*ALERT)),
      ],
      "doorlog": [
        ("log_time", "Takes the time from the phone clock", f.method(*TIME)),
        ("log_store", "Saves the events (database, file or list)", f.method(*STORE) or "lists_add_items" in f.block_types),
        ("log_show", "Shows the list of events", shows_list),
      ],
      "bluetooth": [
        ("bt_component", "Uses a BluetoothClient component", "BluetoothClient" in f.types),
        ("bt_connect", "Connects to the HC-05", f.method(*CONN)),
        ("bt_send", "Sends text commands", f.method(*SEND)),
        ("bt_status", "Asks for STATUS? when needed", f.has_text("STATUS?")),
      ],
    }

SRC_EXT = (".kt", ".java", ".dart", ".js", ".jsx", ".ts", ".tsx", ".py", ".swift", ".cs", ".xml", ".gradle")
def checks_for_source(text):
    has = lambda s: s in text
    return {
      "lamp": [("lamp_send", "Mentions LAMP:1 / LAMP:0", has("LAMP:"))],
      "plug": [("plug_send", "Mentions PLUG:1 / PLUG:0", has("PLUG:"))],
      "door": [("door_parse", "Mentions DOOR:OPEN / DOOR:CLOSED", has("DOOR:"))],
      "temp": [("temp_parse", "Mentions TEMP:", has("TEMP:"))],
      "alarm": [("alarm_limit", "Mentions LIMIT:", has("LIMIT:")), ("alarm_parse", "Mentions ALARM:", has("ALARM:"))],
      "doorlog": [("log_time", "Handles time stamps", bool(re.search(r"Date|time|Clock|Instant", text, re.I))),
                  ("log_store", "Stores events", bool(re.search(r"SharedPreferences|SQLite|Room|database|TinyDB|file|list", text, re.I)))],
      "bluetooth": [("bt_status", "Mentions STATUS?", has("STATUS?")), ("bt_api", "Uses a Bluetooth API", bool(re.search(r"bluetooth", text, re.I)))],
    }

def main():
    app_dir = os.path.join(ROOT, "mobile-app")
    aias = sorted(glob.glob(os.path.join(app_dir, "**", "*.aia"), recursive=True))
    kind, note, raw = "none", "No .aia file or app source found in mobile-app/", {}
    try:
        if aias:
            kind, note = "aia", f"App Inventor export: {os.path.relpath(aias[0], ROOT)}"
            raw = checks_for_aia(read_aia(aias[0]))
        else:
            text = ""
            for base, _, files in os.walk(app_dir):
                for fn in files:
                    if fn.endswith(SRC_EXT):
                        text += open(os.path.join(base, fn), errors="replace").read(400000) + "\n"
            if text.strip(): kind, note, raw = "source", "Source code scan (no .aia found): weaker evidence", checks_for_source(text)
    except (zipfile.BadZipFile, ValueError, KeyError, ET.ParseError, json.JSONDecodeError) as e:
        kind, note = "invalid", f"The .aia could not be read ({e}). Export it again from App Inventor (Projects > Export selected project)."
    groups = {g: {"checks": [{"id": i, "title": t, "ok": bool(ok)} for i, t, ok in cs]} for g, cs in raw.items()}
    for g in groups.values(): g["passed"] = sum(c["ok"] for c in g["checks"]); g["total"] = len(g["checks"])
    result = {"kind": kind, "note": note, "groups": groups}
    print(f"APP CHECK ({kind}): {note}")
    for g, v in groups.items():
        print(f"  {g}: {v['passed']}/{v['total']}")
        for c in v["checks"]:
            if not c["ok"]: print(f"      missing: {c['title']}")
    if OUT: json.dump(result, open(OUT, "w"), indent=2)
    return 0

if __name__ == "__main__": sys.exit(main())
