"""Locate and inspect the firmware image (the .out / .elf that IAR, Keil or GCC builds) inside a project folder."""
import os, struct

HAL_FUNCS = ["Lamp_Init", "Lamp_Set", "Plug_Init", "Plug_Set", "Door_Init", "Door_IsOpen", "Lm35_Init", "Lm35_ReadDeciC",
             "Serial_Init", "Serial_Read", "Serial_Write", "Time_Init", "Time_Millis"]
APP_FUNCS = ["App_Init", "App_Update"]
EXTS = (".out", ".elf", ".axf")
SKIP_DIRS = {".git", "__MACOSX", "node_modules"}

def is_arm_elf(path):
    try:
        with open(path, "rb") as f: h = f.read(20)
    except OSError: return False
    return len(h) >= 20 and h[:4] == b"\x7fELF" and h[4] == 1 and h[5] == 1 and struct.unpack("<H", h[18:20])[0] == 40

def candidates(root):
    found = []
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if f.lower().endswith(EXTS):
                p = os.path.join(base, f)
                if is_arm_elf(p): found.append(p)
    # newest build wins; prefer IAR's usual Exe folder when times are equal
    found.sort(key=lambda p: (os.path.getmtime(p), "exe" in p.lower().split(os.sep), os.path.getsize(p)), reverse=True)
    return found

def symbols(path):
    from elftools.elf.elffile import ELFFile
    with open(path, "rb") as f:
        st = ELFFile(f).get_section_by_name(".symtab")
        return {s.name for s in st.iter_symbols() if s["st_shndx"] != "SHN_UNDEF"} if st else None

def inspect(path):
    """-> (ok, message)"""
    try: syms = symbols(path)
    except Exception as e: return False, f"the image could not be read ({e})"
    if syms is None: return False, "the image has no symbol table: build with debug information and do not strip it"
    missing = [f for f in HAL_FUNCS + APP_FUNCS if f not in syms]
    if missing: return False, "missing in the image: " + ", ".join(missing)
    return True, ""
