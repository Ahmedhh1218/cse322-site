"""Runs the blocks of an App Inventor project (.aia) against a model of the board's Bluetooth protocol.

It is a small interpreter for the blocks students use in this project (events, variables, procedures, control, logic,
math, text, lists, and the components Button, Label, TextBox, Switch, CheckBox, ListView, ListPicker, Image, Clock,
TinyDB, File, Notifier, Sound/Player and BluetoothClient). It does not render anything: it keeps every component property
in a dictionary, so a test can "tap" a button, advance the phone clock and read what the screen would show.

Anything the interpreter does not know is recorded in `Runner.unsupported`: the grader then does not trust a failing result.
"""
import copy, datetime, json, math, re, zipfile
import xml.etree.ElementTree as ET

BOARD_ADDRESS = "00:11:22:33:44:55"
MAC = re.compile(r"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}")


def tag(el): return el.tag.split("}", 1)[-1]


class AppError(Exception): pass
class Stop(Exception): pass          # end of a procedure / event body (never used for errors)
class Break(Exception): pass


# ---- value helpers (App Inventor coercions) -------------------------------------------------------------------
def is_num(v): return isinstance(v, (int, float)) and not isinstance(v, bool)
def to_num(v):
    if is_num(v): return v
    if isinstance(v, bool): raise AppError("a true/false value is not a number")
    if isinstance(v, str):
        try: return int(v) if re.fullmatch(r"-?\d+", v.strip()) else float(v)
        except ValueError: raise AppError(f"'{v}' is not a number")
    raise AppError("not a number")
def fmt(v):
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, float):
        if v == int(v) and abs(v) < 1e15: return str(int(v))
        return repr(v)
    if isinstance(v, list): return "(" + " ".join(fmt(x) for x in v) + ")"
    if v is None: return ""
    return str(v)
def truth(v):
    if isinstance(v, bool): return v
    if isinstance(v, str): return v.lower() == "true"
    raise AppError("expected true or false")
def same(a, b):
    try:
        if (is_num(a) or is_num(b)): return to_num(a) == to_num(b)
    except AppError: pass
    if isinstance(a, list) and isinstance(b, list): return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    return fmt(a) == fmt(b)


class Comp:
    def __init__(self, name, typ, props):
        self.name, self.type, self.props = name, typ, dict(props)
    def get(self, k, default=None): return self.props.get(k, default)


DEFAULTS = {"Label": {"Text": "", "Visible": True}, "Button": {"Text": "", "Enabled": True, "Visible": True},
            "TextBox": {"Text": "", "Hint": ""}, "Switch": {"On": False, "Text": ""}, "CheckBox": {"Checked": False, "Text": ""},
            "ListView": {"Elements": [], "Selection": "", "SelectionIndex": 0}, "ListPicker": {"Elements": [], "Selection": "", "SelectionIndex": 0, "Text": ""},
            "Image": {"Picture": ""}, "Clock": {"TimerInterval": 1000, "TimerEnabled": True, "TimerAlwaysFires": True},
            "Slider": {"ThumbPosition": 50}, "BluetoothClient": {"DelimiterByte": 0, "Secure": True}, "Form": {}}
BOOL_PROPS = {"Visible", "Enabled", "On", "Checked", "TimerEnabled", "TimerAlwaysFires", "Secure"}
NUM_PROPS = {"TimerInterval", "DelimiterByte", "ThumbPosition"}


def scm_value(k, v):
    if k in BOOL_PROPS: return str(v).lower() == "true"
    if k in NUM_PROPS:
        try: return int(float(v))
        except ValueError: return v
    return v


# ---- the phone -------------------------------------------------------------------------------------------------
class Runner:
    STEP_LIMIT = 20000

    def __init__(self, aia_path, board):
        self.board = board                       # object with .feed(text) and .out (bytes the board sent)
        self.unsupported, self.errors = set(), []
        self.calls = []                          # notifier / sound / vibration calls: (kind, text)
        self.sent = []                           # texts the app sent over Bluetooth
        self.inbox = bytearray()
        self.connected = False
        self.connect_calls = []
        self.tinydb, self.files = {}, {}
        self.now = datetime.datetime(2026, 12, 1, 10, 15, 0)       # the phone's clock
        self.comps, self.events, self.globals, self.procs = {}, {}, {}, {}
        self.steps = 0
        self.hung = False
        self._load(aia_path)
        self.clock_acc = {n: 0.0 for n, c in self.comps.items() if c.type == "Clock"}

    # -- loading ---
    def _load(self, path):
        with zipfile.ZipFile(path) as z:
            scms = sorted(n for n in z.namelist() if n.endswith(".scm"))
            if not scms: raise AppError("no screens in the .aia")
            main = next((n for n in scms if n.endswith("/Screen1.scm")), scms[0])
            self.screen_name = main.rsplit("/", 1)[-1][:-4]
            if len(scms) > 1: self.multi_screen = True
            else: self.multi_screen = False
            raw = z.read(main).decode("utf-8", "replace")
            body = "\n".join(l for l in raw.splitlines() if l.strip() not in ("#|", "$JSON", "|#"))
            form = json.loads(body)["Properties"]
            self._add_comp(form, is_form=True)
            bky = main[:-4] + ".bky"
            if bky in z.namelist():
                root = ET.fromstring(z.read(bky))
                tops = [t for t in root if tag(t) == "block"]
                self.tops = [t for t in tops if t.get("disabled") != "true"]
        self.env0 = {}
        for t in self.tops:
            if t.get("type") == "global_declaration": pass
        for t in self.tops:
            ty = t.get("type")
            if ty == "procedures_defnoreturn" or ty == "procedures_defreturn":
                name = self._field(t, "NAME"); args = [a.get("name") for a in (next((c for c in t if tag(c) == "mutation"), None) or []) if tag(a) == "arg"]
                self.procs[name] = (t, args)
            elif ty == "component_event":
                m = next(c for c in t if tag(c) == "mutation")
                key = (m.get("instance_name") or self._field(t, "COMPONENT_SELECTOR"), m.get("event_name"))
                self.events.setdefault(key, []).append(t)
        for t in self.tops:
            if t.get("type") == "global_declaration":
                name = self._field(t, "NAME")
                self.globals[name] = self.eval(self._value(t, "VALUE"), {})

    def _add_comp(self, node, is_form=False):
        name = node.get("$Name"); typ = node.get("$Type")
        props = dict(DEFAULTS.get("Form" if is_form else typ, {}))
        for k, v in node.items():
            if not k.startswith("$") and k != "Uuid": props[k] = scm_value(k, v)
        if typ in ("ListView", "ListPicker") and isinstance(props.get("ElementsFromString"), str) and props["ElementsFromString"]:
            props["Elements"] = [x.strip() for x in props["ElementsFromString"].split(",")]
        self.comps[name] = Comp(name, "Form" if is_form else typ, props)
        for c in node.get("$Components", []): self._add_comp(c)

    # -- xml helpers ---
    @staticmethod
    def _field(b, name):
        for c in b:
            if tag(c) == "field" and c.get("name") == name: return c.text or ""
        return None
    @staticmethod
    def _value(b, name):
        for c in b:
            if tag(c) == "value" and c.get("name") == name:
                return next((x for x in c if tag(x) == "block"), None)
        return None
    @staticmethod
    def _stmt(b, name):
        for c in b:
            if tag(c) == "statement" and c.get("name") == name:
                return next((x for x in c if tag(x) == "block"), None)
        return None
    @staticmethod
    def _mut(b): return next((c for c in b if tag(c) == "mutation"), None)

    # -- phone services ---
    def advance(self, ms):
        """Move the phone and the board forward in 10 ms steps; Clock timers fire."""
        left = ms
        while left > 0:
            dt = min(10, left); left -= dt
            self.now += datetime.timedelta(milliseconds=dt)
            self.board.advance(dt)
            self._pull_board()
            for n, c in self.comps.items():
                if c.type == "Clock" and c.get("TimerEnabled", True):
                    self.clock_acc[n] += dt
                    iv = max(1, c.get("TimerInterval", 1000))
                    while self.clock_acc[n] >= iv:
                        self.clock_acc[n] -= iv
                        self.fire(n, "Timer")

    def _pull_board(self):
        if self.board.out:
            data = bytes(self.board.out); self.board.out.clear()
            if self.connected: self.inbox += data

    def set_phone_time(self, dt): self.now = dt

    # -- events ---
    def fire(self, inst, event, args=()):
        handled = False
        if self.hung: return False
        for blk in self.events.get((inst, event), []):
            handled = True
            names = [p.get("name") for p in (self._mut(blk) or []) if tag(p) == "eventparam"]
            env = dict(zip(names, args))
            try:
                self.steps = 0
                self.run_chain(self._stmt(blk, "DO"), env)
            except (Stop, Break): pass
            except AppError as e:
                self.errors.append(f"{inst}.{event}: {e}")
                if "too long" in str(e): self.hung = True      # the real app would freeze: nothing else runs
            except RecursionError: self.errors.append(f"{inst}.{event}: endless recursion")
        return handled

    def start(self):
        self.fire(self.screen_name, "Initialize")

    # -- UI driver ---
    def click(self, name):
        c = self.comps[name]
        if not c.get("Enabled", True) or not c.get("Visible", True): return False
        return self.fire(name, "Click")
    def set_text(self, name, text): self.comps[name].props["Text"] = text
    def toggle(self, name):
        c = self.comps[name]
        k = "On" if c.type == "Switch" else "Checked"
        c.props[k] = not c.props.get(k, False)
        return self.fire(name, "Changed") or self.fire(name, "Click")
    def snapshot(self):
        keys = ("Text", "Picture", "BackgroundColor", "TextColor", "Visible", "Elements", "Image", "On", "Checked", "Enabled")
        return {(n, k): copy.deepcopy(c.props[k]) for n, c in self.comps.items() if c.type != "Form" for k in keys if k in c.props}
    def texts(self):
        out = []
        for n, c in self.comps.items():
            for k in ("Text", "Elements", "Selection"):
                v = c.props.get(k)
                if v: out.append(fmt(v))
        return "\n".join(out)

    def clone(self):
        r = copy.copy(self)
        for k in ("comps", "globals", "tinydb", "files", "unsupported", "errors", "calls", "sent", "clock_acc"):
            setattr(r, k, copy.deepcopy(getattr(self, k)))
        r.inbox = bytearray(self.inbox); r.board = copy.deepcopy(self.board)
        r.connect_calls = list(self.connect_calls)
        return r

    # -- execution ---
    def run_chain(self, blk, env):
        while blk is not None:
            self.exec(blk, env)
            nxt = next((c for c in blk if tag(c) == "next"), None)
            blk = next((x for x in nxt if tag(x) == "block"), None) if nxt is not None else None

    def tick(self):
        self.steps += 1
        if self.steps > self.STEP_LIMIT: raise AppError("the blocks ran for too long (endless loop?)")

    def exec(self, b, env):
        self.tick(); ty = b.get("type")
        if b.get("disabled") == "true": return
        if ty == "controls_if":
            m = self._mut(b); n = int(m.get("elseif", "0")) if m is not None else 0; has_else = m is not None and m.get("else") == "1"
            for i in range(n + 1):
                if truth(self.eval(self._value(b, f"IF{i}"), env)):
                    self.run_chain(self._stmt(b, f"DO{i}"), env); return
            if has_else: self.run_chain(self._stmt(b, "ELSE"), env)
        elif ty == "controls_forRange":
            var = self._field(b, "VAR"); a = to_num(self.eval(self._value(b, "START"), env)); e = to_num(self.eval(self._value(b, "END"), env)); s = to_num(self.eval(self._value(b, "STEP"), env))
            i = a
            while (s > 0 and i <= e) or (s < 0 and i >= e):
                env2 = dict(env); env2[var] = i
                try: self.run_chain(self._stmt(b, "DO"), env2)
                except Break: break
                i += s
                if s == 0: break
        elif ty == "controls_forEach":
            var = self._field(b, "VAR")
            for it in list(self.eval(self._value(b, "LIST"), env)):
                env2 = dict(env); env2[var] = it
                try: self.run_chain(self._stmt(b, "DO"), env2)
                except Break: break
        elif ty == "controls_while":
            while truth(self.eval(self._value(b, "TEST"), env)):
                self.tick()
                try: self.run_chain(self._stmt(b, "DO"), env)
                except Break: break
        elif ty == "controls_break": raise Break()
        elif ty == "controls_eval_but_ignore": self.eval(self._value(b, "VALUE"), env)
        elif ty in ("controls_closeScreen", "controls_closeApplication", "controls_closeScreenWithValue"): raise Stop()
        elif ty in ("controls_openAnotherScreen", "controls_openAnotherScreenWithStartValue"):
            self.unsupported.add("controls_openAnotherScreen")
        elif ty == "lexical_variable_set":
            name = self._field(b, "VAR"); val = self.eval(self._value(b, "VALUE"), env)
            if name.startswith("global "): self.globals[name[7:]] = val
            else:
                if name not in env: raise AppError(f"variable {name} is not defined here")
                env[name] = val
        elif ty == "local_declaration_statement":
            env2 = dict(env); m = self._mut(b)
            names = [x.get("name") for x in m if tag(x) == "localname"]
            for i, nm in enumerate(names): env2[nm] = self.eval(self._value(b, f"DECL{i}"), env)
            self.run_chain(self._stmt(b, "STACK"), env2)
        elif ty == "procedures_callnoreturn": self.call_proc(b, env)
        elif ty == "component_set_get": self.prop(b, env)
        elif ty == "component_method": self.method(b, env)
        elif ty in ("lists_add_items", "lists_insert_item", "lists_remove_item", "lists_replace_item", "lists_append_list"): self.list_stmt(b, env)
        else:
            self.unsupported.add(ty)

    def call_proc(self, b, env):
        m = self._mut(b); name = m.get("name")
        if name not in self.procs: raise AppError(f"procedure {name} does not exist")
        defn, params = self.procs[name]
        env2 = {p: self.eval(self._value(b, f"ARG{i}"), env) for i, p in enumerate(params)}
        try:
            if defn.get("type") == "procedures_defreturn":
                return self.eval(self._value(defn, "RETURN"), env2)
            self.run_chain(self._stmt(defn, "STACK"), env2)
        except Stop: pass
        return None

    def eval(self, b, env):
        if b is None: return None
        self.tick(); ty = b.get("type"); F = lambda n: self._field(b, n); V = lambda n: self.eval(self._value(b, n), env)
        m = self._mut(b)
        items = lambda p, key="items": [V(f"{p}{i}") for i in range(int(m.get(key, "2")))] if m is not None else []
        if ty == "text":
            t = F("TEXT") or ""
            return t.replace("\\n", "\n").replace("\\t", "\t").replace("\\\\", "\\")
        if ty in ("math_number", "math_number_radix"):
            s = F("NUM") or "0"
            try: return int(s) if re.fullmatch(r"-?\d+", s) else float(s)
            except ValueError: return 0
        if ty in ("logic_boolean", "logic_false"): return (F("BOOL") or "FALSE").upper() == "TRUE"
        if ty == "logic_negate": return not truth(V("BOOL"))
        if ty == "logic_compare":
            a, c = V("A"), V("B"); op = F("OP")
            return same(a, c) if op == "EQ" else not same(a, c)
        if ty == "logic_operation":
            op = F("OP"); n = int(m.get("items", "2")) if m is not None else 2
            vals = [self._value(b, "A"), self._value(b, "B")] + [self._value(b, f"{'ABCDEFGH'[i]}") for i in range(2, n)]
            for blk in vals[:n]:
                v = truth(self.eval(blk, env))
                if op == "AND" and not v: return False
                if op == "OR" and v: return True
            return op == "AND"
        if ty == "math_compare":
            a, c = to_num(V("A")), to_num(V("B")); op = F("OP")
            return {"EQ": a == c, "NEQ": a != c, "LT": a < c, "LTE": a <= c, "GT": a > c, "GTE": a >= c}[op]
        if ty == "math_add": return sum(to_num(x) for x in items("NUM"))
        if ty == "math_subtract": return to_num(V("A")) - to_num(V("B"))
        if ty == "math_multiply":
            r = 1
            for x in items("NUM"): r *= to_num(x)
            return r
        if ty == "math_division":
            d = to_num(V("B"))
            if d == 0: raise AppError("division by zero")
            return to_num(V("A")) / d
        if ty == "math_power": return to_num(V("A")) ** to_num(V("B"))
        if ty == "math_divide":
            a, c = to_num(V("DIVIDEND")), to_num(V("DIVISOR")); op = F("OP")
            if c == 0: raise AppError("division by zero")
            return {"MODULO": a % c, "REMAINDER": math.fmod(a, c), "QUOTIENT": int(a / c)}[op]
        if ty in ("math_single", "math_abs", "math_neg", "math_round", "math_ceiling", "math_floor"):
            x = to_num(V("NUM")); op = F("OP") or {"math_abs": "ABS", "math_neg": "NEG", "math_round": "ROUND", "math_ceiling": "CEILING", "math_floor": "FLOOR"}[ty]
            return {"ABS": abs(x), "NEG": -x, "ROOT": math.sqrt(x), "ROUND": int(math.floor(x + 0.5)), "CEILING": math.ceil(x), "FLOOR": math.floor(x),
                    "LN": math.log(x), "EXP": math.exp(x)}[op]
        if ty == "math_on_list":
            vals = [to_num(x) for x in items("NUM")]; return max(vals) if F("OP") == "MAX" else min(vals)
        if ty == "math_is_a_number":
            try: to_num(V("NUM")); return True
            except AppError: return False
        if ty == "math_convert_number": return to_num(V("NUM"))
        if ty == "math_random_int": return to_num(V("FROM"))
        if ty == "text_join": return "".join(fmt(x) for x in items("ADD"))
        if ty == "text_length": return len(fmt(V("VALUE")))
        if ty == "text_isEmpty": return fmt(V("VALUE")) == ""
        if ty == "text_trim": return fmt(V("TEXT")).strip()
        if ty == "text_changeCase": return fmt(V("TEXT")).upper() if F("OP") == "UPCASE" else fmt(V("TEXT")).lower()
        if ty == "text_compare":
            a, c = fmt(V("TEXT1")), fmt(V("TEXT2")); op = F("OP")
            return {"LT": a < c, "GT": a > c, "EQUAL": a == c, "NEQ": a != c}[op]
        if ty == "text_starts_at": return fmt(V("TEXT")).find(fmt(V("PIECE"))) + 1
        if ty == "text_contains":
            t, p = fmt(V("TEXT")), V("PIECE"); op = F("OP") or "CONTAINS"
            if op == "CONTAINS": return fmt(p) in t
            ps = [fmt(x) for x in p]; return any(x in t for x in ps) if op == "CONTAINS_ANY" else all(x in t for x in ps)
        if ty == "text_split":
            t, at = fmt(V("TEXT")), fmt(V("AT")); op = F("OP")
            if op == "SPLIT": return t.split(at)
            if op == "SPLITATFIRST": return t.split(at, 1)
            return re.split("|".join(re.escape(c) for c in at), t) if at else [t]
        if ty == "text_split_at_spaces": return fmt(V("TEXT")).split()
        if ty == "text_segment":
            t = fmt(V("TEXT")); s = int(to_num(V("START"))); l = int(to_num(V("LENGTH")))
            if s < 1 or s - 1 + l > len(t): raise AppError("text segment out of range")
            return t[s - 1:s - 1 + l]
        if ty == "text_replace_all": return fmt(V("TEXT")).replace(fmt(V("SEGMENT")), fmt(V("REPLACEMENT")))
        if ty == "text_reverse": return fmt(V("VALUE"))[::-1]
        if ty == "lists_create_with": return items("ADD")
        if ty == "lists_length": return len(V("LIST"))
        if ty == "lists_is_empty": return len(V("LIST")) == 0
        if ty == "lists_is_in": return any(same(V("ITEM"), x) for x in V("LIST"))
        if ty == "lists_position_in":
            it, lst = V("ITEM"), V("LIST"); return next((i + 1 for i, x in enumerate(lst) if same(x, it)), 0)
        if ty == "lists_select_item":
            lst, i = V("LIST"), int(to_num(V("NUM")))
            if not 1 <= i <= len(lst): raise AppError("list index out of range")
            return lst[i - 1]
        if ty == "lists_copy": return list(V("LIST"))
        if ty == "lists_reverse": return list(reversed(V("LIST")))
        if ty == "lists_but_first": return V("LIST")[1:]
        if ty == "lists_but_last": return V("LIST")[:-1]
        if ty == "lists_join_with_separator": return fmt(V("SEPARATOR")).join(fmt(x) for x in V("LIST"))
        if ty == "lists_pick_random_item": return V("LIST")[0]
        if ty == "lexical_variable_get":
            name = F("VAR")
            if name.startswith("global "):
                if name[7:] not in self.globals: raise AppError(f"variable {name} is not defined")
                return self.globals[name[7:]]
            if name not in env: raise AppError(f"variable {name} is not defined here")
            return env[name]
        if ty == "local_declaration_expression":
            env2 = dict(env); names = [x.get("name") for x in m if tag(x) == "localname"]
            for i, nm in enumerate(names): env2[nm] = self.eval(self._value(b, f"DECL{i}"), env)
            return self.eval(self._value(b, "RETURN"), env2)
        if ty == "controls_choose": return self.eval(self._value(b, "THENRETURN" if truth(V("TEST")) else "ELSERETURN"), env)
        if ty == "controls_do_then_return":
            self.run_chain(self._stmt(b, "STM"), env); return V("VALUE")
        if ty == "procedures_callreturn": return self.call_proc(b, env)
        if ty == "component_set_get": return self.prop(b, env)
        if ty == "component_method": return self.method(b, env)
        if ty == "component_component_block": return self.comps.get(F("COMPONENT_SELECTOR"))
        if ty == "helpers_dropdown": return F("OPTION")
        if ty.startswith("color_"): return F("COLOR") or ty
        self.unsupported.add(ty); return None

    # -- list statements ---
    def list_stmt(self, b, env):
        ty = b.get("type"); V = lambda n: self.eval(self._value(b, n), env); m = self._mut(b)
        lst = V("LIST")
        if not isinstance(lst, list): raise AppError("not a list")
        if ty == "lists_add_items":
            for i in range(int(m.get("items", "1"))): lst.append(self.eval(self._value(b, f"ITEM{i}"), env))
        elif ty == "lists_insert_item":
            i = int(to_num(V("INDEX")))
            if not 1 <= i <= len(lst) + 1: raise AppError("list index out of range")
            lst.insert(i - 1, V("ITEM"))
        elif ty == "lists_remove_item":
            i = int(to_num(V("INDEX")))
            if not 1 <= i <= len(lst): raise AppError("list index out of range")
            del lst[i - 1]
        elif ty == "lists_replace_item":
            i = int(to_num(V("NUM")))
            if not 1 <= i <= len(lst): raise AppError("list index out of range")
            lst[i - 1] = V("ITEM")
        elif ty == "lists_append_list": lst.extend(V("LIST1") if self._value(b, "LIST1") is not None else [])

    # -- components ---
    def _inst(self, b, m):
        name = m.get("instance_name") or self._field(b, "COMPONENT_SELECTOR")
        if m.get("is_generic") == "true": return None
        return self.comps.get(name)

    def prop(self, b, env):
        m = self._mut(b); c = self._inst(b, m); p = m.get("property_name")
        if c is None:
            self.unsupported.add("generic_or_unknown_component"); return None
        if m.get("set_or_get") == "set":
            v = self.eval(self._value(b, "VALUE"), env)
            c.props[p] = v if c.type != "BluetoothClient" else v
            if p == "ElementsFromString": c.props["Elements"] = [x.strip() for x in fmt(v).split(",")] if v else []
            if p == "TimerInterval": self.clock_acc[c.name] = 0.0
            return None
        if c.type == "BluetoothClient":
            if p == "IsConnected": return self.connected
            if p == "AddressesAndNames": return [f"{BOARD_ADDRESS} HC-05"]
        if c.type == "ListPicker" and p == "Elements" and c.props.get("Elements") == [] : pass
        return c.props.get(p, "" if p not in BOOL_PROPS else False)

    def method(self, b, env):
        m = self._mut(b); c = self._inst(b, m); name = m.get("method_name")
        if c is None:
            self.unsupported.add("generic_or_unknown_component"); return None
        A = lambda i: self.eval(self._value(b, f"ARG{i}"), env)
        t = c.type
        if t == "BluetoothClient":
            if name in ("Connect", "ConnectWithUUID"):
                addr = fmt(A(0)); self.connect_calls.append(addr)
                ok = bool(MAC.match(addr)) or "HC-05" in addr
                self.connected = ok; return ok
            if name == "Disconnect": self.connected = False; return None
            if name == "IsDevicePaired": return True
            if name in ("SendText", "Send1ByteNumber"):
                if not self.connected: raise AppError("Bluetooth is not connected")
                txt = fmt(A(0)) if name == "SendText" else chr(int(to_num(A(0))) & 0xFF)
                self.sent.append(txt); self.board.feed(txt); return None
            if name == "BytesAvailableToReceive": return len(self.inbox) if self.connected else 0
            if name == "ReceiveText":
                if not self.connected: raise AppError("Bluetooth is not connected")
                n = int(to_num(A(0)))
                if n < 0:
                    d = c.props.get("DelimiterByte", 0)
                    idx = self.inbox.find(bytes([d]))
                    if idx < 0: return ""             # the real call would wait for the delimiter byte
                    txt = bytes(self.inbox[:idx]).decode("latin-1"); del self.inbox[:idx + 1]; return txt
                txt = bytes(self.inbox[:n]).decode("latin-1"); del self.inbox[:n]; return txt
            self.unsupported.add(f"BluetoothClient.{name}"); return None
        if t == "Clock": return self._clock(name, A, c)
        if t == "TinyDB":
            if name == "StoreValue": self.tinydb[fmt(A(0))] = copy.deepcopy(A(1)); return None
            if name == "GetValue": return copy.deepcopy(self.tinydb.get(fmt(A(0)), A(1)))
            if name == "ClearAll": self.tinydb.clear(); return None
            if name == "ClearTag": self.tinydb.pop(fmt(A(0)), None); return None
            if name == "GetTags": return list(self.tinydb)
        if t == "File":
            if name in ("AppendToFile", "SaveFile"):
                fn = fmt(A(1)); self.files[fn] = (self.files.get(fn, "") if name == "AppendToFile" else "") + fmt(A(0)); return None
            if name == "ReadFrom":
                self.fire(c.name, "GotText", [self.files.get(fmt(A(0)), "")]); return None
            if name == "Delete": self.files.pop(fmt(A(0)), None); return None
        if t == "Notifier":
            if name.startswith("Show"): self.calls.append(("notifier", fmt(A(0)))); return None
            return None
        if t in ("Sound", "Player"):
            if name in ("Play", "Start", "Vibrate"): self.calls.append(("sound", name)); return None
            return None
        if t in ("ListPicker", "ListView") and name == "Open": return None
        if t in ("TextBox",) and name in ("HideKeyboard", "RequestFocus"): return None
        self.unsupported.add(f"{t}.{name}"); return None

    def _clock(self, name, A, c):
        if name == "Now": return self.now
        if name == "SystemTime": return int(self.now.timestamp() * 1000)
        if name in ("FormatDateTime", "FormatDate", "FormatTime"):
            inst = A(0) if name != "FormatDate" and name != "FormatTime" else A(0)
            pat = fmt(A(1)) if name == "FormatDateTime" else ("MMM d, yyyy" if name == "FormatDate" else "hh:mm:ss a")
            if name in ("FormatDate", "FormatTime") and A(1) not in (None, ""): pat = fmt(A(1))
            return java_format(inst, pat)
        if name == "Hour": return A(0).hour
        if name == "Minute": return A(0).minute
        if name == "Second": return A(0).second
        if name == "Year": return A(0).year
        if name == "Month": return A(0).month
        if name == "DayOfMonth": return A(0).day
        if name == "MakeInstant": return self.now
        self.unsupported.add(f"Clock.{name}"); return None


def java_format(dt, pat):
    if not isinstance(dt, datetime.datetime): raise AppError("not a date")
    out, i = [], 0
    while i < len(pat):
        ch = pat[i]
        if ch == "'":
            j = pat.find("'", i + 1); j = len(pat) if j < 0 else j
            out.append(pat[i + 1:j]); i = j + 1; continue
        if ch.isalpha():
            j = i
            while j < len(pat) and pat[j] == ch: j += 1
            n = j - i
            h12 = dt.hour % 12 or 12
            out.append({"y": f"{dt.year:04d}" if n != 2 else f"{dt.year % 100:02d}", "M": (dt.strftime("%B") if n >= 4 else dt.strftime("%b") if n == 3 else f"{dt.month:0{n}d}"),
                        "d": f"{dt.day:0{n}d}", "H": f"{dt.hour:0{n}d}", "h": f"{h12:0{n}d}", "m": f"{dt.minute:0{n}d}", "s": f"{dt.second:0{n}d}",
                        "a": "AM" if dt.hour < 12 else "PM", "E": dt.strftime("%A" if n >= 4 else "%a"), "S": f"{dt.microsecond // 1000:03d}"}.get(ch, ch * n))
            i = j
        else:
            out.append(ch); i += 1
    return "".join(out)


# ---- a model of the board's Bluetooth side (what the phone talks to) -------------------------------------
class BoardModel:
    """Implements the project's protocol: the HC-05 plus a board that behaves as the project description says."""
    def __init__(self):
        self.out = bytearray(); self.rx = ""
        self.lamp = self.plug = 0; self.limit = 30; self.alarm = 0
        self.door_open = 0; self.temp_dc = 250; self.t = 0.0; self.next_temp = 1000.0
        self.got = []                                          # every complete line received from the app
    def emit(self, s): self.out += s.encode("latin-1")
    def feed(self, text):
        self.rx += text
        while True:
            m = re.search(r"[\r\n]", self.rx)
            if not m: break
            line, self.rx = self.rx[:m.start()], self.rx[m.end():]
            if line: self.got.append(line); self.handle(line)
    def handle(self, c):
        if c in ("LAMP:1", "LAMP:0"): self.lamp = int(c[5]); self.emit(f"ACK:{c}\n")
        elif c in ("PLUG:1", "PLUG:0"): self.plug = int(c[5]); self.emit(f"ACK:{c}\n")
        elif re.fullmatch(r"LIMIT:\d{1,3}", c): self.limit = int(c[6:]); self.emit(f"ACK:{c}\n"); self._alarm()
        elif c == "STATUS?":
            self.emit(f"LAMP:{self.lamp}\nPLUG:{self.plug}\nDOOR:{'OPEN' if self.door_open else 'CLOSED'}\n{self._temp()}ALARM:{self.alarm}\n")
    def _temp(self): return f"TEMP:{self.temp_dc // 10}.{abs(self.temp_dc) % 10}\n"
    def _alarm(self):
        a = int(self.temp_dc > self.limit * 10)
        if a != self.alarm: self.alarm = a; self.emit(f"ALARM:{a}\n")
    def advance(self, ms):
        self.t += ms
        while self.t >= self.next_temp:
            self.next_temp += 1000; self.emit(self._temp()); self._alarm()
    def set_door(self, is_open):
        if int(is_open) != self.door_open: self.door_open = int(is_open); self.emit(f"DOOR:{'OPEN' if is_open else 'CLOSED'}\n")
    def set_temp(self, dc): self.temp_dc = dc
