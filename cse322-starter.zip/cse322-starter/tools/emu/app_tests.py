#!/usr/bin/env python3
"""Runs the student's App Inventor blocks (mobile-app/*.aia) against a model of the board and checks what the app does.

  python3 tools/emu/app_tests.py <project folder> <out.json> [static.json]

The app is driven like a user would: its controls are found by what they do (a control "is" the lamp control if tapping it
makes the board switch the lamp on), not by their names. Output groups: lamp plug door temp alarm doorlog bluetooth.
If the blocks use something the interpreter does not know, the result is combined with the static check (the better of the two).
"""
import glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aia_runner import Runner, BoardModel, AppError, fmt
import datetime

PICK = "00:11:22:33:44:55 HC-05"
ALARM_WORDS = re.compile(r"alarm|warn|high|danger|alert|hot|exceed|over|!", re.I)


class Session:
    def __init__(self, aia, runners):
        self.board = BoardModel()
        self.r = Runner(aia, self.board)
        runners.append(self.r)
        self.r.start()
        self.connect()
        self.r.advance(1500)

    def connect(self):
        r = self.r
        if r.connected: return
        for n, c in list(r.comps.items()):
            if c.type in ("ListPicker",):
                r.fire(n, "BeforePicking")
                els = c.props.get("Elements") or [PICK]
                c.props["Selection"] = els[0] if els else PICK
                c.props["SelectionIndex"] = 1
                r.fire(n, "AfterPicking")
                if r.connected: return
        for n, c in list(r.comps.items()):
            if c.type == "Button":
                r.click(n)
                if r.connected: return
        for n, c in list(r.comps.items()):
            if c.type == "ListView":
                c.props["Elements"] = c.props.get("Elements") or [PICK]; c.props["Selection"] = c.props["Elements"][0]
                r.fire(n, "AfterPicking")
                if r.connected: return

    def actions(self):
        out = []
        for n, c in self.r.comps.items():
            if c.type == "Button": out.append((n, "click"))
            elif c.type in ("Switch", "CheckBox"): out.append((n, "toggle"))
        return out

    def do(self, act, wait=400):
        n, k = act
        if k == "click": self.r.click(n)
        else: self.r.toggle(n)
        self.r.advance(wait)

    def textboxes(self): return [n for n, c in self.r.comps.items() if c.type == "TextBox"]
    def strings(self):
        out = set()
        for n, c in self.r.comps.items():
            if c.type == "Form": continue
            for k in ("Text", "Selection"):
                v = c.props.get(k)
                if v: out.add(fmt(v))
            for e in c.props.get("Elements") or []: out.add(fmt(e))
        return out


def entries(r):
    out = []
    for n, c in r.comps.items():
        if c.type in ("ListView", "ListPicker"): out += [fmt(e) for e in c.props.get("Elements") or []]
        if c.type == "Label" and re.search(r"\d:\d\d", fmt(c.props.get("Text", ""))): out += fmt(c.props["Text"]).splitlines()
    for v in r.tinydb.values():
        out += [fmt(x) for x in v] if isinstance(v, list) else [fmt(v)]
    out += [l for t in r.files.values() for l in t.splitlines()]
    return out


def run(aia):
    runners, checks = [], {}
    def add(group, cid, title, ok): checks.setdefault(group, []).append({"id": cid, "title": title, "ok": bool(ok)})
    S = lambda: Session(aia, runners)
    def safe(group, cid, title, fn):
        try: ok = fn()
        except AppError as e: ok = False; runners[-1].errors.append(f"{cid}: {e}")
        except (RecursionError, KeyError, IndexError, TypeError, ValueError, AttributeError, ZeroDivisionError) as e:
            ok = False; runners[-1].errors.append(f"{cid}: internal {type(e).__name__}: {e}")
        add(group, cid, title, ok)

    s0 = S()
    acts = s0.actions()

    # ---- bluetooth -------------------------------------------------------------------
    safe("bluetooth", "connects", "the app connects to the HC-05 (BluetoothClient.Connect on start or from a button/list picker)", lambda: s0.r.connected)
    safe("bluetooth", "status", "the app asks the board for its state (sends STATUS? as a full line)", lambda: "STATUS?" in s0.board.got or
         any("STATUS?" in S_.board.got for S_ in [_after(S, a) for a in acts[:8]]))
    def garbage():
        s = S(); s.board.emit("HELLO\nLAMP:7\n%%%\nTEMP:\nTEMP:abc\nDOOR:\nALARM:9\n\n"); s.r.advance(2500)
        return not s.r.errors
    safe("bluetooth", "garbage", "unexpected lines from the board do not break the app", garbage)
    def sends_lines():
        return all(l == l.strip() and l for l in s0.board.got) and (not s0.r.sent or all(t.endswith(("\n", "\r")) for t in s0.r.sent))
    safe("bluetooth", "lines", "every message the app sends ends with a newline", sends_lines)

    # ---- lamp / plug: find the controls by behaviour ---------------------------------
    def relay(group, attr, label):
        found = {}
        def on():
            for a in acts:
                s = S(); s.do(a)
                if getattr(s.board, attr) == 1: found["on"] = a; return True
            return False
        safe(group, "on", f"a control switches the {label} on (sends {label.upper()}:1 and the board obeys)", on)
        def off():
            if "on" not in found: return False
            for a in acts:
                s = S(); s.do(found["on"]); s.do(a)
                if getattr(s.board, attr) == 0: return True
            return False
        safe(group, "off", f"a control switches the {label} off again (sends {label.upper()}:0)", off)
        def other():
            if "on" not in found: return False
            for a in acts:
                s = S(); s.do(a)
                if getattr(s.board, attr) == 1 and a != found["on"]: pass
            s = S(); s.do(found["on"])
            return getattr(s.board, "plug" if attr == "lamp" else "lamp") == 0
        safe(group, "independent", f"the {label} control leaves the other relay alone", other)
        return found
    relay("lamp", "lamp", "lamp"); relay("plug", "plug", "plug")

    # ---- door ------------------------------------------------------------------------
    def changed(s, before): return " | ".join(sorted(s.strings() - before)).lower()
    def door_open():
        s = S(); b = s.strings(); s.board.set_door(1); s.r.advance(2500); return "open" in changed(s, b)
    def door_closed():
        s = S(); s.board.set_door(1); s.r.advance(2500); b = s.strings(); s.board.set_door(0); s.r.advance(2500); return "clos" in changed(s, b)
    safe("door", "open", "the screen shows that the door is OPEN when the board reports DOOR:OPEN", door_open)
    safe("door", "closed", "the screen shows that the door is CLOSED when the board reports DOOR:CLOSED", door_closed)

    # ---- temperature -----------------------------------------------------------------
    def temp(dc, shown):
        def f():
            s = S(); b = s.strings(); s.board.set_temp(dc); s.r.advance(2500); return shown in changed(s, b)
        return f
    safe("temp", "shown", "the temperature the board reports (27.5) appears on the screen", temp(275, "27.5"))
    safe("temp", "updates", "the temperature on the screen follows new readings (31.2)", temp(312, "31.2"))
    def temp_neg():
        s = S(); b = s.strings(); s.board.set_temp(95); s.r.advance(2500); return "9.5" in changed(s, b)
    safe("temp", "single_digit", "a one-digit temperature (9.5) is shown correctly", temp_neg)

    # ---- limit and alarm -------------------------------------------------------------
    limit = {}
    def find_limit():
        cands = [("lost", t) for t in s0.textboxes()] + [("act", a) for a in acts]
        for kind, c in cands:
            s = S()
            for t in s.textboxes(): s.r.set_text(t, "25")
            if kind == "lost": s.r.fire(c, "LostFocus"); s.r.advance(300)
            else: s.do(c)
            if "LIMIT:25" in s.board.got: limit["c"] = (kind, c); return True
        return False
    safe("alarm", "limit_sent", "the app sends the limit typed by the user as LIMIT:<n>", find_limit)
    def apply(s, v):
        kind, c = limit["c"]
        for t in s.textboxes(): s.r.set_text(t, str(v))
        if kind == "lost": s.r.fire(c, "LostFocus"); s.r.advance(300)
        else: s.do(c)
    def limit_follows():
        if "c" not in limit: return False
        s = S(); apply(s, 40); return "LIMIT:40" in s.board.got and s.board.limit == 40
    safe("alarm", "limit_follows", "a different value gives a different command (LIMIT:40)", limit_follows)
    def alarm_on():
        s = S(); n = len(s.r.calls); b = s.strings(); s.board.set_temp(350); s.r.advance(2500)
        return len(s.r.calls) > n or bool(ALARM_WORDS.search(changed(s, b)))
    safe("alarm", "alert", "when the board reports ALARM:1 the app alerts the user (notifier, sound or a visible warning)", alarm_on)
    def alarm_quiet():
        s = S(); n = len(s.r.calls); s.board.set_temp(250); s.r.advance(4000); return len(s.r.calls) == n
    safe("alarm", "quiet", "no alert while the temperature is below the limit", alarm_quiet)
    def alarm_clear():
        s = S(); s.board.set_temp(350); s.r.advance(2500); a = s.r.snapshot(); s.board.set_temp(250); s.r.advance(2500)
        return not s.r.errors and s.r.snapshot() != a
    safe("alarm", "clears", "the warning goes away when the board reports ALARM:0", alarm_clear)

    # ---- door log (time stamped by the phone) ---------------------------------------
    def log_open():
        s = S(); s.r.set_phone_time(datetime.datetime(2026, 12, 1, 14, 37, 5)); s.board.set_door(1); s.r.advance(2500)
        return any("open" in e.lower() and "37" in e for e in entries(s.r))
    safe("doorlog", "open_entry", "a door-open event adds a log entry that says open and carries the phone time", log_open)
    def log_closed():
        s = S(); s.r.set_phone_time(datetime.datetime(2026, 12, 1, 14, 37, 5)); s.board.set_door(1); s.r.advance(2500)
        s.r.set_phone_time(datetime.datetime(2026, 12, 1, 14, 52, 9)); s.board.set_door(0); s.r.advance(2500)
        return any("clos" in e.lower() and "52" in e for e in entries(s.r))
    safe("doorlog", "closed_entry", "a door-closed event adds its own entry with its own time", log_closed)
    def log_history():
        s = S(); s.board.set_door(1); s.r.advance(2500); s.board.set_door(0); s.r.advance(2500); s.board.set_door(1); s.r.advance(2500)
        return len([e for e in entries(s.r) if re.search(r"open|clos", e, re.I)]) >= 3
    safe("doorlog", "history", "earlier entries stay in the log (three events, three entries)", log_history)
    def log_once():
        s = S(); s.board.set_door(1); s.r.advance(6000)
        return len([e for e in entries(s.r) if "open" in e.lower()]) == 1
    safe("doorlog", "once", "one event gives one entry (nothing is logged again on every timer tick)", log_once)

    errs = sorted({e for r in runners for e in r.errors})
    uns = sorted({u for r in runners for u in r.unsupported})
    return checks, errs, uns


def main(project, out, static=None):
    files = sorted(glob.glob(os.path.join(project, "mobile-app", "**", "*.aia"), recursive=True))
    groups = {}
    base = {"kind": "none", "note": "no App Inventor project (.aia) found", "groups": {}}
    if static and os.path.exists(static):
        try: base = json.load(open(static))
        except Exception: pass
    if not files:
        json.dump(base, open(out, "w"), indent=1); print("no .aia: static result only"); return
    try:
        checks, errs, uns = run(files[0])
    except Exception as e:
        print(f"APP could not be run: {type(e).__name__}: {e}")
        base["note"] = (base.get("note", "") + f" The blocks could not be run ({type(e).__name__}); static check only.").strip()
        json.dump(base, open(out, "w"), indent=1); return
    for g, cs in checks.items():
        for c in cs: print(f"TEST app {g}.{c['id']} {'PASS' if c['ok'] else 'FAIL'}")
        groups[g] = {"passed": sum(c["ok"] for c in cs), "total": len(cs), "checks": cs}
    for e in errs[:10]: print("APPERR", e)
    note = "The app's blocks were run against a model of the board."
    if uns:
        note += f" The interpreter does not know: {', '.join(uns[:8])}; the better of the run and the static check counts."
        for g, d in base.get("groups", {}).items():
            if g in groups and d.get("total") and d["passed"] / d["total"] > groups[g]["passed"] / groups[g]["total"]: groups[g] = d
    if errs: note += f" Errors while running: {errs[0]}"
    json.dump({"kind": "dynamic", "note": note, "unsupported": uns, "errors": errs, "groups": groups}, open(out, "w"), indent=1)
    print(note)


def _after(S, a):
    s = S(); s.do(a); return s


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
