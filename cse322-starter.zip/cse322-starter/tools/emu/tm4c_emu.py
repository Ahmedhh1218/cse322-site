#!/usr/bin/env python3
"""A small TM4C123GH6PM emulator for grading the Home Appliances project.

It runs a student's compiled ELF (built by IAR, Keil or GCC) on an emulated Cortex-M4 (Unicorn) and models
only the peripherals this project uses: SYSCTL (clock gates, PLL), GPIO ports, UART0, ADC0, GPTM timers,
SysTick and the NVIC. Behaviour that would be wrong on the real chip is reproduced (for example a write to a
GPIO port whose clock was never enabled is ignored) and reported in `board.diag`.

Not modelled: DMA, PWM, I2C/SPI/CAN, USB, EEPROM, hibernation, FPU timing, exact instruction timing
(every instruction counts as one clock cycle).
"""
import struct
from collections import OrderedDict
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS, UcError
from unicorn import UC_HOOK_MEM_READ_UNMAPPED, UC_HOOK_MEM_WRITE_UNMAPPED, UC_HOOK_MEM_FETCH_UNMAPPED
from unicorn import UC_PROT_ALL, UC_HOOK_CODE
from unicorn.arm_const import (UC_ARM_REG_PC, UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1,
                               UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_R12, UC_ARM_REG_XPSR,
                               UC_ARM_REG_PRIMASK)
import unicorn.unicorn_const as UC

EXC_RETURN = 0xFFFFFFF0
MAGIC = 0x3FFF0                  # handlers 'return' here; Python then unstacks the frame
PIOSC = 16_000_000

def mask_for(size): return (1 << (8 * size)) - 1

class Reg32:
    """Helper for byte/halfword accesses to a 32-bit register."""
    @staticmethod
    def read(val, off, size): return (val >> (8 * (off & 3))) & mask_for(size)
    @staticmethod
    def merge(old, off, size, v):
        sh = 8 * (off & 3); m = mask_for(size) << sh
        return (old & ~m) | ((v << sh) & m)


class Board:
    def __init__(self, elf_path, *, host_baud=115200):
        self.diag = OrderedDict()
        self.host_baud = host_baud
        self.time_ns = 0.0
        self.cycles = 0
        self.dead = None                       # set to a message if the CPU crashed
        self.uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
        self.uc.ctl_set_cpu_model(UC.UC_CPU_ARM_CORTEX_M4) if hasattr(UC, "UC_CPU_ARM_CORTEX_M4") else None
        self.in_handler = False
        self.pending = set()                   # exception numbers (15 = SysTick, 16+n = IRQ n)
        self.sysctl = Sysctl(self)
        self.scs = Scs(self)
        self.gpio = {n: Gpio(self, n, base) for n, base in
                     (("A", 0x40004000), ("B", 0x40005000), ("C", 0x40006000), ("D", 0x40007000),
                      ("E", 0x40024000), ("F", 0x40025000))}
        self.uart0 = Uart(self, 0, 0x4000C000)
        self.adc0 = Adc(self, 0, 0x40038000)
        self.timers = [Timer(self, i, base) for i, base in enumerate(
            (0x40030000, 0x40031000, 0x40032000, 0x40033000, 0x40034000, 0x40035000))]
        self.unknown_pages = {}
        self._map_memory()
        self._map_peripherals()
        self._load(elf_path)
        self.uc.hook_add(UC_HOOK_CODE, lambda uc,a,sz,ud: uc.emu_stop(), begin=MAGIC, end=MAGIC)
        self.uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED, self._unmapped)
        self.reset()

    # ----- diagnostics ---------------------------------------------------------------------------------
    def note(self, key, msg=None):
        if key not in self.diag: self.diag[key] = [msg or key, 0]
        self.diag[key][1] += 1

    # ----- setup ---------------------------------------------------------------------------------------
    def _map_memory(self):
        self.uc.mem_map(0x00000000, 0x40000, UC_PROT_ALL)         # 256 KB flash
        self.uc.mem_map(0x20000000, 0x8000, UC_PROT_ALL)          # 32 KB SRAM

    def _mmio(self, base, size, dev):
        self.uc.mmio_map(base, size, dev.mmio_read, None, dev.mmio_write, None)

    def _map_peripherals(self):
        self._mmio(0x400FE000, 0x1000, self.sysctl)
        self._mmio(0xE000E000, 0x1000, self.scs)
        for g in self.gpio.values(): self._mmio(g.base, 0x1000, g)
        self._mmio(self.uart0.base, 0x1000, self.uart0)
        self._mmio(self.adc0.base, 0x1000, self.adc0)
        for t in self.timers: self._mmio(t.base, 0x1000, t)

    def _unmapped(self, uc, access, address, size, value, user):
        if address >= EXC_RETURN or 0xFFFFFFF0 <= address:
            return False
        if 0x40000000 <= address < 0x60000000 or 0xE0000000 <= address < 0xE0100000:
            page = address & ~0xFFF
            if page not in self.unknown_pages:
                self.unknown_pages[page] = Unknown(self, page)
                self._mmio(page, 0x1000, self.unknown_pages[page])
            return True
        return False

    def _load(self, path):
        with open(path, "rb") as f:
            elf = ELFFile(f)
            self.symbols = {}
            st = elf.get_section_by_name(".symtab")
            if st:
                for s in st.iter_symbols(): self.symbols[s.name] = s["st_value"]
            for seg in elf.iter_segments():
                if seg["p_type"] != "PT_LOAD" or seg["p_filesz"] == 0: continue
                addr = seg["p_paddr"]
                data = seg.data()
                if addr + len(data) <= 0x40000 or (0x20000000 <= addr and addr + len(data) <= 0x20008000):
                    self.uc.mem_write(addr, data)

    # ----- CPU control ----------------------------------------------------------------------------------
    def reset(self):
        sp, pc = struct.unpack("<II", bytes(self.uc.mem_read(0, 8)))
        self.uc.reg_write(UC_ARM_REG_SP, sp)
        self.pc = pc | 1
        self.time_ns = 0.0; self.cycles = 0

    @property
    def sysclk(self): return self.sysctl.sysclk()

    def _vector(self, exc):
        vtor = self.scs.vtor
        return struct.unpack("<I", bytes(self.uc.mem_read(vtor + 4 * exc, 4)))[0]

    def _primask(self):
        try: return self.uc.reg_read(UC_ARM_REG_PRIMASK) & 1
        except Exception: return 0

    def raise_exc(self, exc): self.pending.add(exc)
    def clear_exc(self, exc): self.pending.discard(exc)

    def _take_interrupt(self):
        if self.in_handler or not self.pending or self._primask(): return
        # highest urgency = lowest priority value, ties by exception number
        cands = []
        for e in self.pending:
            if e >= 16 and not self.scs.irq_enabled(e - 16): continue
            cands.append((self.scs.priority(e), e))
        if not cands: return
        _, exc = min(cands)
        if exc >= 16 and not self.scs.irq_pending_line(exc - 16): pass
        self.pending.discard(exc)
        uc = self.uc
        sp = uc.reg_read(UC_ARM_REG_SP)
        pad = 1 if (sp & 4) else 0
        frame = sp - 0x20 - 4 * pad
        xpsr = uc.reg_read(UC_ARM_REG_XPSR)
        regs = [uc.reg_read(r) for r in (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_R12, UC_ARM_REG_LR)]
        ret_pc = self.pc & ~1
        stacked = regs + [ret_pc, (xpsr & ~0x200) | (0x200 if pad else 0)]
        uc.mem_write(frame, struct.pack("<8I", *stacked))
        uc.reg_write(UC_ARM_REG_SP, frame)
        uc.reg_write(UC_ARM_REG_LR, MAGIC | 1)
        self.pc = self._vector(exc) | 1
        self.in_handler = True
        self.cur_exc = exc

    def _exception_return(self):
        uc = self.uc
        frame = uc.reg_read(UC_ARM_REG_SP)
        vals = struct.unpack("<8I", bytes(uc.mem_read(frame, 32)))
        r0, r1, r2, r3, r12, lr, pc, xpsr = vals
        sp = frame + 0x20 + (4 if xpsr & 0x200 else 0)
        for r, v in zip((UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_R12, UC_ARM_REG_LR), (r0, r1, r2, r3, r12, lr)):
            uc.reg_write(r, v)
        uc.reg_write(UC_ARM_REG_SP, sp)
        uc.reg_write(UC_ARM_REG_XPSR, (xpsr & ~0x200 & ~0x1FF) | 0x01000000)
        self.pc = pc | 1
        self.in_handler = False

    SLICE_US = 100.0

    def run_slice(self):
        u = self.uart0
        us = 40.0 if (u.tx or u.rx or u.host_queue or self.adc0.busy or self.time_ns < u.tx_done_at) else 400.0
        n = max(200, min(40000, int(self.sysclk * us / 1e6)))
        if self.dead: self._advance(n); return
        self._take_interrupt()
        try:
            self.uc.emu_start(self.pc, 0xFFFFFFFE, 0, n)
            self.pc = self.uc.reg_read(UC_ARM_REG_PC) | 1
        except UcError as e:
            pc = self.uc.reg_read(UC_ARM_REG_PC)
            self.dead = f"CPU fault ({e}) at pc=0x{pc:08x}"
            self.note("crash", self.dead)
        if (self.pc & ~1) == MAGIC and self.in_handler:
            self._exception_return()
        self._advance(n)

    def _advance(self, cycles):
        f = self.sysclk
        dt = cycles * 1e9 / f
        self.cycles += cycles
        self.time_ns += dt
        self.scs.tick(dt)
        for g in self.gpio.values():
            if g.im or g.is_: g.tick(dt)
        self.uart0.tick(dt)
        if self.adc0.busy: self.adc0.tick(dt)
        for t in self.timers:
            if t.ctl & 1: t.tick(dt)
        if any(self.scs.iser): self.scs.update_lines()

    def run_ms(self, ms):
        target = self.time_ns + ms * 1e6
        while self.time_ns < target: self.run_slice()

    # ----- host side (PuTTY, wiring) ---------------------------------------------------------------------
    @property
    def now_ms(self): return self.time_ns / 1e6

    def set_door_open(self, is_open):
        self.gpio["A"].external[4] = None if is_open else 0     # reed switch to GND when closed

    def set_temp_deci(self, d): self.adc0.analog[0] = max(0.0, d / 10.0 * 0.010)   # LM35: 10 mV per degC

    def lamp_on(self): return self.gpio["A"].driven_level(2) == 1
    def plug_on(self): return self.gpio["A"].driven_level(3) == 1

    def type(self, text, gap_ms=2.0):
        self.uart0.host_send(text.encode("latin-1"), gap_ns=max(gap_ms * 1e6, 0))

    def paste(self, text): self.uart0.host_send(text.encode("latin-1"), gap_ns=0)

    def take_output(self):
        out = bytes(self.uart0.host_rx); self.uart0.host_rx.clear()
        return out.decode("latin-1")


# =========================================================================================================
class Device:
    def __init__(self, board): self.b = board
    def mmio_read(self, uc, off, size, ud):
        try:
            v = self.read(off & ~3)
        except Exception as e:                                  # never let a model error crash the CPU
            self.b.note("model-error-" + type(self).__name__, f"emulator error in {type(self).__name__}: {e}"); v = 0
        return Reg32.read(v, off, size) if size < 4 else v & 0xFFFFFFFF
    def mmio_write(self, uc, off, size, value, ud):
        try:
            if size < 4:
                old = self.read_raw(off & ~3)
                value = Reg32.merge(old, off, size, value)
            self.write(off & ~3, value & 0xFFFFFFFF)
        except Exception as e:
            self.b.note("model-error-" + type(self).__name__, f"emulator error in {type(self).__name__}: {e}")
    def read_raw(self, off): return self.read(off)


class Unknown(Device):
    def __init__(self, board, base): super().__init__(board); self.base = base; self.regs = {}
    def read(self, off):
        self.b.note(f"unmodelled@{self.base:08x}", f"read of unmodelled peripheral register 0x{self.base+off:08X}")
        return self.regs.get(off, 0)
    def write(self, off, v):
        self.b.note(f"unmodelled@{self.base:08x}", f"write to unmodelled peripheral register 0x{self.base+off:08X}")
        self.regs[off] = v


class Sysctl(Device):
    GPIO_BITS = {"A": 0, "B": 1, "C": 2, "D": 3, "E": 4, "F": 5}
    def __init__(self, board):
        super().__init__(board)
        self.rcc = 0x078E3AD1; self.rcc2 = 0x07C06810
        self.gpio_en = 0; self.uart_en = 0; self.adc_en = 0; self.timer_en = 0
        self.pll_locked = False
        self.other = {}
    def sysclk(self):
        if self.rcc2 & 0x80000000:
            bypass = self.rcc2 & 0x800
            div400 = self.rcc2 & (1 << 30)
            sysdiv = (self.rcc2 >> 22) & 0x7F if div400 else (self.rcc2 >> 23) & 0x3F
            if bypass: return PIOSC // (sysdiv + 1) if (self.rcc & (1 << 22) or True) and sysdiv else PIOSC
            if not self.pll_locked: return PIOSC
            return int((400e6 if div400 else 200e6) / (sysdiv + 1))
        bypass = self.rcc & 0x800
        use = self.rcc & (1 << 22)
        sysdiv = (self.rcc >> 23) & 0xF
        if bypass: return PIOSC // (sysdiv + 1) if use else PIOSC
        if not self.pll_locked: return PIOSC
        return int(200e6 / ((sysdiv + 1) if use else 1))
    def clocked(self, kind, idx):
        return bool({"gpio": self.gpio_en, "uart": self.uart_en, "adc": self.adc_en, "timer": self.timer_en}[kind] >> idx & 1)
    def read(self, off):
        if off == 0x050: return 0x40 if self.pll_locked else 0          # RIS: PLLLRIS
        if off == 0x060: return self.rcc
        if off == 0x070: return self.rcc2
        if off == 0x168: return 1 if self.pll_locked else 0             # PLLSTAT.LOCK
        if off == 0x100: return (self.adc_en & 3) << 16
        if off == 0x104: return (self.uart_en & 0xFF) | ((self.timer_en & 0xF) << 16)
        if off == 0x108: return self.gpio_en
        if off in (0x604,): return self.timer_en
        if off == 0x608: return self.gpio_en
        if off == 0x618: return self.uart_en
        if off == 0x638: return self.adc_en
        if off == 0xA04: return self.timer_en
        if off == 0xA08: return self.gpio_en
        if off == 0xA18: return self.uart_en
        if off == 0xA38: return self.adc_en
        return self.other.get(off, 0)
    def write(self, off, v):
        if off == 0x060 or off == 0x070:
            if off == 0x060: self.rcc = v
            else: self.rcc2 = v
            pwrdn = (self.rcc2 & 0x2000) if (self.rcc2 & 0x80000000) else (self.rcc & 0x2000)
            if not pwrdn: self.pll_locked = True
            else: self.pll_locked = False
        elif off == 0x100: self.adc_en = (v >> 16) & 3
        elif off == 0x104: self.uart_en = v & 0xFF; self.timer_en = (v >> 16) & 0xF
        elif off in (0x108, 0x608): self.gpio_en = v & 0x3F
        elif off in (0x604,): self.timer_en = v & 0x3F
        elif off == 0x618: self.uart_en = v & 0xFF
        elif off == 0x638: self.adc_en = v & 3
        elif off in (0x050, 0x058): pass
        else: self.other[off] = v


class Scs(Device):
    """System control space: SysTick, NVIC, SCB."""
    def __init__(self, board):
        super().__init__(board)
        self.vtor = 0
        self.st_ctrl = 0; self.st_reload = 0; self.st_cur = 0; self.st_count_flag = False
        self.iser = [0] * 5; self.ipr = [0] * 140; self.shpr = {}
        self.other = {}
        self.irq_ispr = [0] * 5
        self.st_frac = 0.0; self.st_started = False
    def irq_enabled(self, n): return bool(self.iser[n // 32] >> (n % 32) & 1)
    def irq_pending_line(self, n): return True
    def priority(self, exc):
        if exc == 15: return (self.shpr.get(0xD20, 0) >> 24) & 0xE0
        if exc >= 16: return self.ipr[exc - 16] & 0xE0
        return 0
    def read(self, off):
        if off == 0x010:
            v = (self.st_ctrl & 7) | (0x10000 if self.st_count_flag else 0); self.st_count_flag = False; return v
        if off == 0x014: return self.st_reload
        if off == 0x018: return self.st_cur
        if off == 0x01C: return 0
        if 0x100 <= off < 0x114: return self.iser[(off - 0x100) // 4]
        if 0x180 <= off < 0x194: return self.iser[(off - 0x180) // 4]
        if 0x200 <= off < 0x214: return self.irq_ispr[(off - 0x200) // 4]
        if 0x400 <= off < 0x400 + 140:
            i = off - 0x400; return sum(self.ipr[i + k] << (8 * k) for k in range(4) if i + k < 140)
        if off == 0xD08: return self.vtor
        if off == 0xD04: return 0x4000000 if 15 in self.b.pending else 0
        return self.other.get(off, 0)
    def write(self, off, v):
        if off == 0x010:
            if not (self.st_ctrl & 1) and (v & 1): self.st_started = False
            self.st_ctrl = v & 7
        elif off == 0x014: self.st_reload = v & 0xFFFFFF
        elif off == 0x018: self.st_cur = 0; self.st_count_flag = False
        elif 0x100 <= off < 0x114: self.iser[(off - 0x100) // 4] |= v
        elif 0x180 <= off < 0x194: self.iser[(off - 0x180) // 4] &= ~v
        elif 0x200 <= off < 0x214:
            self.irq_ispr[(off - 0x200) // 4] |= v
            for b in range(32):
                if v >> b & 1: self.b.raise_exc(16 + (off - 0x200) // 4 * 32 + b)
        elif 0x280 <= off < 0x294:
            for b in range(32):
                if v >> b & 1: self.b.clear_exc(16 + (off - 0x280) // 4 * 32 + b)
        elif 0x400 <= off < 0x400 + 140:
            i = off - 0x400
            for k in range(4):
                if i + k < 140: self.ipr[i + k] = (v >> (8 * k)) & 0xFF
        elif off == 0xD08: self.vtor = v & 0xFFFFFF80
        elif off == 0xD04:
            if v & (1 << 26): self.b.raise_exc(15)
            if v & (1 << 25): self.b.clear_exc(15)
        else: self.other[off] = v; self.shpr[off] = v
    def tick(self, dt_ns):
        if not (self.st_ctrl & 1):
            return
        f = self.b.sysclk if self.st_ctrl & 4 else PIOSC // 4
        self.st_frac += dt_ns * f / 1e9
        n = int(self.st_frac); self.st_frac -= n
        if n <= 0: return
        if self.st_cur == 0 and not self.st_started:
            self.st_cur = self.st_reload
        self.st_started = True
        period = self.st_reload + 1
        if n < self.st_cur + 1:
            self.st_cur -= n
            return
        n -= self.st_cur + 1
        wraps = 1 + n // period
        self.st_cur = self.st_reload - (n % period)
        self.st_count_flag = True
        if self.st_ctrl & 2: self.b.raise_exc(15)
        if wraps > 1: self.b.note("systick-missed", "SysTick wrapped more than once between two emulator steps")
    def update_lines(self):
        """Level-sensitive IRQ lines from the peripherals."""
        b = self.b
        lines = {0: b.gpio["A"].irq(), 1: b.gpio["B"].irq(), 2: b.gpio["C"].irq(), 3: b.gpio["D"].irq(),
                 4: b.gpio["E"].irq(), 5: b.uart0.irq(), 17: b.adc0.irq(3), 14: b.adc0.irq(0), 15: b.adc0.irq(1),
                 16: b.adc0.irq(2), 30: b.gpio["F"].irq()}
        for i, t in enumerate(b.timers): lines[19 + i * 2 if i < 4 else 70 + (i - 4) * 2] = t.irq()
        for n, on in lines.items():
            if on: b.raise_exc(16 + n)
            else: b.clear_exc(16 + n)


class Gpio(Device):
    def __init__(self, board, name, base):
        super().__init__(board)
        self.name = name; self.base = base; self.idx = Sysctl.GPIO_BITS[name]
        self.data = 0; self.dir = 0; self.is_ = 0; self.ibe = 0; self.iev = 0; self.im = 0; self.ris = 0
        self.afsel = 0; self.pur = 0; self.pdr = 0; self.den = 0; self.amsel = 0; self.pctl = 0
        self.other = {}
        self.external = [None] * 8          # None = nothing connected (floating); 0/1 = driven by the outside world
        self.analog = {}                    # pin -> volts (unused here, ADC reads board.adc0.analog)
        self.prev_levels = [0] * 8
    def _ok(self, what):
        if not self.b.sysctl.clocked("gpio", self.idx):
            self.b.note(f"gpio{self.name}-noclk", f"GPIO port {self.name} was accessed before its clock was enabled "
                                                 f"(RCGCGPIO bit {self.idx}): on the real chip the access is ignored or faults")
            return False
        return True
    def driven_level(self, bit):
        """Level of the pin as seen by whatever is wired to it (a relay input, say). None = not driven."""
        if (self.den >> bit & 1) and (self.dir >> bit & 1) and not (self.afsel >> bit & 1):
            return self.data >> bit & 1
        return None
    def level(self, bit):
        if not (self.den >> bit & 1): return 0
        if self.amsel >> bit & 1: return 0
        if self.afsel >> bit & 1: return 0
        if self.dir >> bit & 1: return self.data >> bit & 1
        ext = self.external[bit]
        if ext is not None: return ext
        if self.pur >> bit & 1: return 1
        return 0
    def read(self, off):
        if not self._ok("r"): return 0
        if off < 0x400:
            m = (off >> 2) & 0xFF
            return sum(1 << i for i in range(8) if (m >> i & 1) and self.level(i))
        return {0x400: self.dir, 0x404: self.is_, 0x408: self.ibe, 0x40C: self.iev, 0x410: self.im,
                0x414: self.ris, 0x418: self.ris & self.im, 0x420: self.afsel, 0x510: self.pur, 0x514: self.pdr,
                0x51C: self.den, 0x528: self.amsel, 0x52C: self.pctl}.get(off, self.other.get(off, 0))
    def write(self, off, v):
        if not self._ok("w"): return
        if off < 0x400:
            m = (off >> 2) & 0xFF
            self.data = (self.data & ~m) | (v & m)
        elif off == 0x400: self.dir = v & 0xFF
        elif off == 0x404: self.is_ = v & 0xFF
        elif off == 0x408: self.ibe = v & 0xFF
        elif off == 0x40C: self.iev = v & 0xFF
        elif off == 0x410: self.im = v & 0xFF
        elif off == 0x41C: self.ris &= ~v & 0xFF
        elif off == 0x420: self.afsel = v & 0xFF
        elif off == 0x510: self.pur = v & 0xFF
        elif off == 0x514: self.pdr = v & 0xFF
        elif off == 0x51C: self.den = v & 0xFF
        elif off == 0x528: self.amsel = v & 0xFF
        elif off == 0x52C: self.pctl = v
        else: self.other[off] = v
    def mux(self, bit):
        """Peripheral function selected for a pin (PCTL nibble) when AFSEL is set, else None."""
        return (self.pctl >> (4 * bit)) & 0xF if (self.afsel >> bit & 1) else None
    def tick(self, dt):
        for i in range(8):
            lv = self.level(i) if self.b.sysctl.clocked("gpio", self.idx) else 0
            old = self.prev_levels[i]
            if lv != old and not (self.is_ >> i & 1):
                if self.ibe >> i & 1 or (self.iev >> i & 1) == lv: self.ris |= 1 << i
            self.prev_levels[i] = lv
        for i in range(8):                  # level-sensitive pins
            if self.is_ >> i & 1:
                lv = self.prev_levels[i]
                if (self.iev >> i & 1) == lv: self.ris |= 1 << i
                else: self.ris &= ~(1 << i)
    def irq(self): return bool(self.ris & self.im)


class Uart(Device):
    def __init__(self, board, n, base):
        super().__init__(board)
        self.n = n; self.base = base
        self.ibrd = 0; self.fbrd = 0; self.lcrh = 0; self.ctl = 0x300; self.ifls = 0x12; self.im = 0; self.ris = 0
        self.cc = 0; self.other = {}
        self.tx = []; self.tx_done_at = 0.0
        self.rx = []; self.rx_last = 0.0
        self.host_rx = bytearray()          # what the PC (PuTTY) has received
        self.host_queue = []                # (time_ns, byte) scheduled by the PC
        self.host_next = 0.0
        self.host_log_bad = False
    # --- configuration helpers
    def clk(self): return PIOSC if (self.cc & 0xF) == 5 else self.b.sysclk
    def baud(self):
        div = self.ibrd + self.fbrd / 64.0
        if div <= 0: return 0
        return self.clk() / ((8 if self.ctl & 0x20 else 16) * div)
    def frame_bits(self):
        wlen = 5 + ((self.lcrh >> 5) & 3)
        return 1 + wlen + (1 if self.lcrh & 2 else 0) + (2 if self.lcrh & 8 else 1)
    def fifo_depth(self): return 16 if self.lcrh & 0x10 else 1
    def link_ok(self):
        """Would a PC set to host_baud 8N1 understand the board?"""
        bd = self.baud()
        if bd <= 0: return False
        if abs(bd - self.b.host_baud) / self.b.host_baud > 0.03:
            self.b.note("uart-baud", f"UART0 baud rate is {bd:.0f}, but the terminal uses {self.b.host_baud}")
            return False
        if self.frame_bits() != 10 or (self.lcrh >> 5) & 3 != 3:
            self.b.note("uart-frame", "UART0 is not configured for 8 data bits, no parity, 1 stop bit")
            return False
        return True
    def pins_ok(self, which):
        ga = self.b.gpio["A"]
        bit = 1 if which == "tx" else 0
        ok = ga.mux(bit) == 1 and bool(ga.den >> bit & 1)
        if not ok:
            self.b.note(f"uart-pin-{which}", f"PA{bit} is not set up as UART0 {'U0Tx' if which=='tx' else 'U0Rx'} "
                                              f"(AFSEL, PCTL=1 and DEN)")
        return ok
    def _clocked(self):
        if not self.b.sysctl.clocked("uart", 0):
            self.b.note("uart-noclk", "UART0 was accessed before its clock was enabled (RCGCUART bit 0)")
            return False
        return True
    # --- registers
    def read(self, off):
        if not self._clocked(): return 0
        if off == 0x000:
            if self.rx: return self.rx.pop(0)
            return 0
        if off == 0x018:
            fr = 0
            if not self.rx: fr |= 0x10
            if len(self.rx) >= self.fifo_depth(): fr |= 0x40
            if len(self.tx) >= self.fifo_depth(): fr |= 0x20
            if not self.tx: fr |= 0x80
            if self.tx or self.b.time_ns < self.tx_done_at: fr |= 0x08
            return fr
        if off == 0x024: return self.ibrd
        if off == 0x028: return self.fbrd
        if off == 0x02C: return self.lcrh
        if off == 0x030: return self.ctl
        if off == 0x034: return self.ifls
        if off == 0x038: return self.im
        if off == 0x03C: return self.ris
        if off == 0x040: return self.ris & self.im
        if off == 0xFC8: return self.cc
        return self.other.get(off, 0)
    def write(self, off, v):
        if not self._clocked(): return
        if off == 0x000:
            if not (self.ctl & 1 and self.ctl & 0x100):
                self.b.note("uart-tx-off", "UART0 was written while the UART or its transmitter is disabled (CTL.UARTEN / TXE)")
                return
            if len(self.tx) >= self.fifo_depth():
                self.b.note("uart-tx-overrun", "UART0 byte lost: the transmit FIFO was full (check FR.TXFF before writing)")
                return
            self.tx.append(v & 0xFF)
        elif off == 0x024: self.ibrd = v & 0xFFFF
        elif off == 0x028: self.fbrd = v & 0x3F
        elif off == 0x02C: self.lcrh = v & 0xFF
        elif off == 0x030: self.ctl = v & 0xFFFF
        elif off == 0x034: self.ifls = v & 0x3F
        elif off == 0x038: self.im = v & 0x7FF
        elif off == 0x044: self.ris &= ~v
        elif off == 0xFC8: self.cc = v & 0xF
        else: self.other[off] = v
    # --- PC side
    def host_send(self, data, gap_ns):
        t = max(self.host_next, self.b.time_ns)
        ct = self.frame_bits() * 1e9 / self.b.host_baud
        for byte in data:
            self.host_queue.append((t, byte)); t += max(gap_ns, ct)
        self.host_next = t
    def tick(self, dt):
        now = self.b.time_ns
        if not self.b.sysctl.clocked("uart", 0):
            return
        enabled = bool(self.ctl & 1)
        # transmit: one character every frame time
        if self.tx and enabled and now >= self.tx_done_at:
            ct = self.frame_bits() * 1e9 / max(self.baud(), 1.0)
            while self.tx and now >= self.tx_done_at:
                byte = self.tx.pop(0)
                start = max(self.tx_done_at, now - dt)
                self.tx_done_at = start + ct
                if self.link_ok() and self.pins_ok("tx"): self.host_rx.append(byte)
        # receive: characters sent by the PC
        while self.host_queue and self.host_queue[0][0] <= now:
            t, byte = self.host_queue.pop(0)
            if not (enabled and self.ctl & 0x200) or not self.link_ok() or not self.pins_ok("rx"):
                if enabled and self.ctl & 0x200 and not self.link_ok(): pass
                continue
            if len(self.rx) >= self.fifo_depth():
                self.b.note("uart-rx-overrun", "UART0 received a character while the receive FIFO was full: it was lost "
                                               "(read the data register more often, or use the FIFO / an interrupt)")
                continue
            self.rx.append(byte); self.rx_last = now
        # interrupt status
        rx_trig = {0: 2, 1: 4, 2: 8, 3: 12, 4: 14}.get((self.ifls >> 3) & 7, 8) if self.lcrh & 0x10 else 1
        tx_trig = {0: 14, 1: 12, 2: 8, 3: 4, 4: 2}.get(self.ifls & 7, 8) if self.lcrh & 0x10 else 0
        if len(self.rx) >= rx_trig: self.ris |= 0x10
        if self.rx and (now - self.rx_last) > 32 * 1e9 / max(self.baud(), 1.0): self.ris |= 0x40
        if (not self.tx) or len(self.tx) <= tx_trig and self.lcrh & 0x10: self.ris |= 0x20
    def irq(self): return bool(self.ris & self.im)


class Adc(Device):
    SS = {0: (0x040, 8), 1: (0x060, 4), 2: (0x080, 4), 3: (0x0A0, 1)}
    def __init__(self, board, n, base):
        super().__init__(board)
        self.n = n; self.base = base
        self.actss = 0; self.ris = 0; self.im = 0; self.emux = 0; self.ssmux = [0] * 4; self.ssctl = [0] * 4
        self.fifo = [[] for _ in range(4)]
        self.analog = {}                    # channel -> volts
        self.busy = {}                      # sequencer -> time when its samples are ready
        self.other = {}
    def irq(self, ss): return bool(self.ris & self.im & (1 << ss))
    def _clocked(self):
        if not self.b.sysctl.clocked("adc", 0):
            self.b.note("adc-noclk", "ADC0 was accessed before its clock was enabled (RCGCADC bit 0)")
            return False
        return True
    def _channel_volts(self, ch):
        if ch == 0:       # AIN0 = PE3
            ge = self.b.gpio["E"]
            if not (ge.amsel >> 3 & 1):
                self.b.note("adc-pin", "PE3 is not configured as an analog pin (GPIOAMSEL bit 3)")
                return 0.0
            if ge.den >> 3 & 1: self.b.note("adc-den", "PE3 should have its digital function disabled (GPIODEN bit 3 = 0) for analog input")
            return self.analog.get(0, 0.0)
        return 0.0
    def read(self, off):
        if not self._clocked(): return 0
        if off == 0x000: return self.actss
        if off == 0x004: return self.ris
        if off == 0x008: return self.im
        if off == 0x00C: return self.ris & self.im
        if off == 0x014: return self.emux
        if off == 0x030: return self.other.get(off, 0)
        for s, (base, depth) in self.SS.items():
            if off == base: return self.ssmux[s]
            if off == base + 4: return self.ssctl[s]
            if off == base + 8: return self.fifo[s].pop(0) if self.fifo[s] else 0
            if off == base + 12:
                n = len(self.fifo[s]); return (0x100 if n == 0 else 0) | (0x1000 if n >= depth else 0) | ((n % depth) << 4)
        return self.other.get(off, 0)
    def write(self, off, v):
        if not self._clocked(): return
        if off == 0x000: self.actss = v & 0xF
        elif off == 0x008: self.im = v & 0xF
        elif off == 0x00C: self.ris &= ~v
        elif off == 0x014: self.emux = v
        elif off == 0x028:
            for s in range(4):
                if v >> s & 1:
                    if not (self.actss >> s & 1): self.b.note("adc-ss-off", "ADC0 trigger ignored: the sample sequencer is not enabled (ACTSS)")
                    elif not (self.emux >> (4 * s) & 0xF) == 0: pass
                    else: self.busy[s] = self.b.time_ns + 3000.0
        else:
            for s, (base, depth) in self.SS.items():
                if off == base: self.ssmux[s] = v; return
                if off == base + 4: self.ssctl[s] = v; return
            self.other[off] = v
    def _convert(self, s):
        steps = []
        for i in range(self.SS[s][1]):
            nib = (self.ssctl[s] >> (4 * i)) & 0xF
            steps.append((i, nib))
            if nib & 2: break
        for i, nib in steps:
            ch = (self.ssmux[s] >> (4 * i)) & 0xF
            volts = self._channel_volts(ch)
            code = max(0, min(4095, int(round(volts / 3.3 * 4095))))
            if len(self.fifo[s]) < self.SS[s][1]: self.fifo[s].append(code)
            if nib & 4: self.ris |= 1 << s
    def tick(self, dt):
        for s in list(self.busy):
            if self.b.time_ns >= self.busy[s]:
                del self.busy[s]; self._convert(s)


class Timer(Device):
    """General-purpose timer, 32-bit (CFG=0) periodic / one-shot, timer A only."""
    def __init__(self, board, i, base):
        super().__init__(board)
        self.i = i; self.base = base
        self.cfg = 0; self.tamr = 0; self.ctl = 0; self.imr = 0; self.ris = 0; self.tailr = 0xFFFFFFFF
        self.cur = 0xFFFFFFFF; self.frac = 0.0; self.other = {}
    def _clocked(self):
        if not self.b.sysctl.clocked("timer", self.i):
            self.b.note(f"timer{self.i}-noclk", f"Timer {self.i} was accessed before its clock was enabled (RCGCTIMER bit {self.i})")
            return False
        return True
    def read(self, off):
        if not self._clocked(): return 0
        return {0x00: self.cfg, 0x04: self.tamr, 0x0C: self.ctl, 0x18: self.imr, 0x1C: self.ris, 0x20: self.ris & self.imr,
                0x28: self.tailr, 0x48: self.tailr, 0x50: self.cur}.get(off, self.other.get(off, 0))
    def write(self, off, v):
        if not self._clocked(): return
        if off == 0x00: self.cfg = v & 7
        elif off == 0x04: self.tamr = v
        elif off == 0x0C:
            if v & 1 and not self.ctl & 1: self.cur = self.tailr
            self.ctl = v
        elif off == 0x18: self.imr = v
        elif off == 0x24: self.ris &= ~v
        elif off in (0x28,): self.tailr = v; (setattr(self, "cur", v) if not self.ctl & 1 else None)
        else: self.other[off] = v
    def tick(self, dt):
        if not self.ctl & 1: return
        self.frac += dt * self.b.sysclk / 1e9
        n = int(self.frac); self.frac -= n
        while n > 0:
            if n > self.cur:
                n -= self.cur + 1
                self.ris |= 1
                if (self.tamr & 3) == 1: self.ctl &= ~1; self.cur = self.tailr; return
                self.cur = self.tailr
            else:
                self.cur -= n; n = 0
    def irq(self): return bool(self.ris & self.imr)
