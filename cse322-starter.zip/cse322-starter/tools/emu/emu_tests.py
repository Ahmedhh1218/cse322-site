#!/usr/bin/env python3
"""Run the Bluetooth-protocol conformance tests against the firmware image on an emulated TM4C123.
Usage: emu_tests.py <project folder | image.out> [result.json]
Prints  TEST <group> <name> PASS|FAIL  lines (read by the grader), DIAG lines and SUMMARY."""
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tm4c_emu import Board
import find_image, json

class T:
    def __init__(self, elf): self.elf = elf; self.failed = 0; self.diag = {}; self.b = None
    def boot(self):
        if self.b:
            for k, v in self.b.diag.items(): self.diag.setdefault(k, v)
        self.b = Board(self.elf); self.b.set_door_open(False); self.b.set_temp_deci(250); self.b.run_ms(5); self.b.take_output()
    def check(self, g, n, ok):
        print(f"TEST {g} {n} {'PASS' if ok else 'FAIL'}"); self.failed += (not ok)
    def run(self, ms): self.b.run_ms(ms)
    def out(self): return self.b.take_output().replace("\r", "")
    def send(self, text, wait=0):
        """The phone sends text over Bluetooth (9600 baud: about 1 ms per character), then we let the board answer."""
        self.b.take_output(); self.b.type(text, gap_ms=0); self.run(len(text) * 1.1 + 60 + wait); return self.out()
    def temp_is(self, out, t):
        return any(abs(float(m) - t) <= 0.35 for m in re.findall(r"TEMP:(-?\d+\.\d)\n", out))
    def temps(self, out): return len(re.findall(r"TEMP:", out))

def run_all(elf, quiet=False):
    t = T(elf); b = lambda: t.b; has = lambda o, s: s in o
    # lamp
    t.boot(); o = t.send("LAMP:1\n")
    t.check("lamp", "on_drives_relay", b().lamp_on()); t.check("lamp", "on_ack", has(o, "ACK:LAMP:1\n"))
    o = t.send("LAMP:0\n")
    t.check("lamp", "off_drives_relay", not b().lamp_on()); t.check("lamp", "off_ack", has(o, "ACK:LAMP:0\n"))
    t.check("lamp", "plug_untouched", not b().plug_on())
    # plug
    t.boot(); o = t.send("PLUG:1\n")
    t.check("plug", "on_drives_relay", b().plug_on()); t.check("plug", "on_ack", has(o, "ACK:PLUG:1\n"))
    o = t.send("PLUG:0\n")
    t.check("plug", "off_drives_relay", not b().plug_on()); t.check("plug", "off_ack", has(o, "ACK:PLUG:0\n"))
    t.check("plug", "lamp_untouched", not b().lamp_on())
    # door
    t.boot(); t.run(100); t.out()
    b().set_door_open(True); t.run(100); o = t.out()
    t.check("door", "open_reported", o.count("DOOR:OPEN\n") == 1)
    b().set_door_open(False); t.run(100); o = t.out()
    t.check("door", "closed_reported", o.count("DOOR:CLOSED\n") == 1)
    t.run(500); o = t.out()
    t.check("door", "no_repeat_without_change", "DOOR:" not in o)
    # temperature
    t.boot(); b().set_temp_deci(275); t.run(950); o = t.out()
    t.check("temp", "not_before_1s", "TEMP:" not in o)
    t.run(150); o = t.out()
    t.check("temp", "sent_after_1s", t.temp_is(o, 27.5))
    b().set_temp_deci(301); t.run(1000); o = t.out()
    t.check("temp", "follows_sensor", t.temp_is(o, 30.1))
    t.run(3000); o = t.out()
    t.check("temp", "once_per_second", t.temps(o) == 3)
    # alarm
    t.boot(); b().set_temp_deci(250); o = t.send("LIMIT:30\n")
    t.check("alarm", "limit_ack", has(o, "ACK:LIMIT:30\n"))
    t.run(1500); o = t.out(); t.check("alarm", "quiet_below_limit", "ALARM:1" not in o)
    b().set_temp_deci(305); t.run(1100); o = t.out(); t.check("alarm", "raised_above_limit", o.count("ALARM:1\n") == 1)
    t.run(3000); o = t.out(); t.check("alarm", "sent_once_per_transition", "ALARM:" not in o)
    b().set_temp_deci(300); t.run(1100); o = t.out(); t.check("alarm", "cleared_at_limit", o.count("ALARM:0\n") == 1)
    o = t.send("LIMIT:20\n"); t.run(1100); o += t.out(); t.check("alarm", "new_limit_applies", has(o, "ALARM:1\n"))
    # status and framing
    t.boot(); t.send("LAMP:1\n"); t.send("PLUG:1\n"); b().set_door_open(True); b().set_temp_deci(228); t.run(100); t.out()
    o = t.send("STATUS?\n", wait=120)
    t.check("bluetooth", "status_lamp", has(o, "LAMP:1\n")); t.check("bluetooth", "status_plug", has(o, "PLUG:1\n"))
    t.check("bluetooth", "status_door", has(o, "DOOR:OPEN\n")); t.check("bluetooth", "status_temp", t.temp_is(o, 22.8))
    t.check("bluetooth", "status_alarm", has(o, "ALARM:0\n"))
    t.boot(); t.b.type("LAM", gap_ms=0); t.run(30); o = t.send("P:1\r\n")
    t.check("bluetooth", "split_and_crlf", b().lamp_on() and has(o, "ACK:LAMP:1\n"))
    t.boot(); o = t.send("HELLO\n") + t.send("LAMP:7\n") + t.send("\n") + t.send("LIMIT:abc\n")
    t.check("bluetooth", "bad_commands_ignored", (not b().lamp_on()) and "ACK" not in o)
    t.boot(); o = t.send("LAMP:1\nPLUG:1\nLAMP:0\n", wait=60)
    t.check("bluetooth", "several_commands_in_a_row", (not b().lamp_on()) and b().plug_on() and o.count("ACK:") == 3)
    t.boot(); b().type("X" * 2000, gap_ms=0); t.run(2400); t.out()
    o = t.send("\nLAMP:1\n"); t.check("bluetooth", "survives_overlong_line", b().lamp_on())
    if t.b:
        for k, v in t.b.diag.items(): t.diag.setdefault(k, v)
    for k, (msg, n) in t.diag.items(): print(f"DIAG {k} x{n}: {msg}")
    print(f"SUMMARY failed={t.failed}")
    return t

HW_DIAG = re.compile(r"^(gpio.-noclk|uart-wrong|uart-baud|uart-frame|uart-pin-.*|uart-noclk|uart-tx-off|adc-noclk|adc-pin|adc-den|timer.-noclk|crash)$")

def main(path, out_json=None):
    checks, image, failed, tests = [], None, 0, []
    def add(title, ok, hint=""): checks.append({"title": title, "ok": bool(ok), "skipped": False, "hint": hint})
    if os.path.isdir(path):
        c = find_image.candidates(path)
        image = c[0] if c else None
        if not image:
            print("NOIMAGE no firmware image (.out / .elf) found in the project folder")
    else: image = path
    if image:
        ok, msg = find_image.inspect(image)
        print("IMAGE", os.path.relpath(image, path) if os.path.isdir(path) else image)
        add("The firmware image (.out/.elf) is in the project and contains the HAL and app functions", ok, msg)
        if ok:
            import io, contextlib
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                try: t = run_all(image, quiet=True)
                except Exception as e: t = None; print(f"EMUERROR {e}")
            sys.stdout.write(buf.getvalue())
            if t is not None:
                failed = t.failed
                tests = re.findall(r"^TEST (\S+) (\S+) (PASS|FAIL)$", buf.getvalue(), re.M)
                crash = [m for k, (m, n) in t.diag.items() if k == "crash"]
                add("The firmware runs on the board without crashing", not crash, crash[0] if crash else "")
                bad = [m for k, (m, n) in t.diag.items() if HW_DIAG.match(k)]
                add("The peripherals are configured correctly (clocks, HC-05 on UART1 at 9600 baud on PB0/PB1, analog pin)", not bad,
                    "; ".join(bad[:2]))
            else:
                add("The firmware runs on the board without crashing", False, "the emulator could not run it")
    else:
        add("The firmware image (.out/.elf) is in the project and contains the HAL and app functions", False,
            "build the project in IAR and zip the whole project folder including the Debug/Exe/*.out file")
    if out_json:
        json.dump({"image": image and os.path.basename(image), "checks": checks, "tests": tests}, open(out_json, "w"), indent=1)
    return failed

if __name__ == "__main__":
    sys.exit(1 if main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None) else 0)
