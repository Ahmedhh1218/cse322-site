#!/usr/bin/env python3
"""Run the terminal-protocol conformance tests against the firmware image on an emulated TM4C123.
Usage: emu_tests.py <project folder | image.out> [result.json]
Prints  TEST <group> <name> PASS|FAIL  lines (read by the grader), DIAG lines and SUMMARY."""
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tm4c_emu import Board
import find_image, json

class T:
    def __init__(self, elf): self.elf = elf; self.failed = 0; self.diag = {}; self.b = None
    def boot(self):
        if self.b:
            for k, v in self.b.diag.items(): self.diag.setdefault(k, v)
        self.b = Board(self.elf); self.b.set_door_open(False); self.b.set_temp_deci(250); self.b.run_ms(5); self.b.take_output()
    def check(self, g, n, ok):
        print(f"TEST {g} {n} {'PASS' if ok else 'FAIL'}"); self.failed += (not ok)
    def run(self, ms): self.b.run_ms(ms)
    def out(self): return self.b.take_output().replace("\r", "")
    def raw(self): return self.b.take_output()
    def type(self, s, gap=2.0):
        self.b.type(s, gap_ms=gap); self.run(len(s) * max(gap, 0.1) + 8)
    def cmd(self, text, enter="\r"):
        self.type(text); self.b.take_output()
        self.b.type(enter); self.run(60); self._raw = self.b.take_output(); return self._raw.replace("\r", "")
    def temp_is(self, out, t):
        return any(abs(float(m) - t) <= 0.35 for m in re.findall(r"TEMP (-?\d+\.\d)\n", out))
    def temps(self, out): return len(re.findall(r"TEMP ", out))

def run_all(elf, quiet=False):
    t = T(elf); b = lambda: t.b; has = lambda o, s: s in o
    # lamp
    t.boot(); o = t.cmd("LAMP ON")
    t.check("lamp", "on_drives_relay", b().lamp_on()); t.check("lamp", "on_reply", has(o, "LAMP ON\n"))
    o = t.cmd("LAMP OFF")
    t.check("lamp", "off_drives_relay", not b().lamp_on()); t.check("lamp", "off_reply", has(o, "LAMP OFF\n"))
    t.check("lamp", "plug_untouched", not b().plug_on())
    # plug
    t.boot(); o = t.cmd("PLUG ON")
    t.check("plug", "on_drives_relay", b().plug_on()); t.check("plug", "on_reply", has(o, "PLUG ON\n"))
    o = t.cmd("PLUG OFF")
    t.check("plug", "off_drives_relay", not b().plug_on()); t.check("plug", "off_reply", has(o, "PLUG OFF\n"))
    t.check("plug", "lamp_untouched", not b().lamp_on())
    # door
    t.boot(); t.run(100); t.out()
    b().set_door_open(True); t.run(100); o = t.out()
    t.check("door", "open_reported", o.count("DOOR OPEN\n") == 1)
    b().set_door_open(False); t.run(100); o = t.out()
    t.check("door", "closed_reported", o.count("DOOR CLOSED\n") == 1)
    t.run(500); o = t.out()
    t.check("door", "no_repeat_without_change", "DOOR " not in o)
    # temperature
    t.boot(); b().set_temp_deci(275); t.run(950); o = t.out()
    t.check("temp", "not_before_1s", "TEMP " not in o)
    t.run(150); o = t.out()
    t.check("temp", "sent_after_1s", t.temp_is(o, 27.5))
    b().set_temp_deci(301); t.run(1000); o = t.out()
    t.check("temp", "follows_sensor", t.temp_is(o, 30.1))
    t.run(3000); o = t.out()
    t.check("temp", "once_per_second", t.temps(o) == 3)
    # alarm
    t.boot(); b().set_temp_deci(250); o = t.cmd("LIMIT 30")
    t.check("alarm", "limit_reply", has(o, "LIMIT 30\n"))
    t.run(1500); o = t.out(); t.check("alarm", "quiet_below_limit", "ALARM ON" not in o)
    b().set_temp_deci(305); t.run(1100); o = t.out(); t.check("alarm", "raised_above_limit", o.count("ALARM ON\n") == 1)
    t.run(3000); o = t.out(); t.check("alarm", "sent_once_per_transition", "ALARM " not in o)
    b().set_temp_deci(300); t.run(1100); o = t.out(); t.check("alarm", "cleared_at_limit", o.count("ALARM OFF\n") == 1)
    t.type("LIMIT 20\r"); t.run(1100); o = t.out(); t.check("alarm", "new_limit_applies", has(o, "ALARM ON\n"))
    # door log
    t.boot(); o = t.cmd("LOG"); t.check("doorlog", "empty_log", has(o, "LOG EMPTY"))
    t.boot(); t.run(2050); b().set_door_open(True); t.run(3000); b().set_door_open(False); t.run(100)
    t.out(); o = t.cmd("LOG")
    t.check("doorlog", "records_open_and_close_times",
            has(o, "LOG 2 OPEN\n") and has(o, "LOG 5 CLOSED\n") and o.find("LOG 2 OPEN") < o.find("LOG 5 CLOSED"))
    t.boot(); t.run(1050)
    for i in range(8): b().set_door_open(i % 2 == 0); t.run(1000)
    t.out(); o = t.cmd("LOG")
    t.check("doorlog", "keeps_last_five_only", o.count("LOG ") == 5 and "LOG 3 OPEN" not in o and has(o, "LOG 4 CLOSED\n") and has(o, "LOG 8 CLOSED\n"))
    # terminal
    t.boot(); t.type("LAM"); o = t.out(); t.check("terminal", "echoes_typed_characters", has(o, "LAM"))
    t.boot(); t.type("AB\x08"); o = t.raw(); t.check("terminal", "backspace_is_echoed", "\b" in o or "\x7f" in o)
    t.boot(); t.cmd("LAMX\x08P ON"); t.check("terminal", "backspace_edits_the_line", b().lamp_on())
    t.boot(); t.cmd("LAMP ON"); r = t._raw
    t.check("terminal", "replies_end_with_crlf", "LAMP ON\r\n" in r and r.count("\n") == r.count("\r\n"))
    t.boot(); t.cmd("LAMP ON", "\n"); i = b().lamp_on(); t.cmd("LAMP OFF", "\r\n"); i = i and not b().lamp_on()
    t.cmd("LAMP ON", "\r"); i = i and b().lamp_on(); t.check("terminal", "enter_as_cr_lf_or_crlf", i)
    t.boot(); o = t.cmd("PLUG ON", "\r\n"); t.check("terminal", "crlf_gives_no_error", "ERR" not in o)
    t.boot(); t.cmd("  lamp   on  "); t.check("terminal", "case_and_spaces_ignored", b().lamp_on())
    t.boot()
    for ch in "LAMP ON": t.type(ch, gap=30)
    t.type("\r"); t.check("terminal", "characters_one_at_a_time", b().lamp_on())
    t.boot(); t.type("LAMP ON\rPLUG ON\rLAMP OFF\r", gap=0); t.run(100)
    t.check("terminal", "several_commands_in_a_row", (not b().lamp_on()) and b().plug_on())
    t.boot(); o = t.cmd("HELLO"); t.check("terminal", "unknown_command_gives_err", has(o, "ERR") and not b().lamp_on() and not b().plug_on())
    t.boot(); i = True
    o = t.cmd("LAMP 7"); i = i and "ERR" in o and not b().lamp_on()
    o = t.cmd("LAMP"); i = i and "ERR" in o
    o = t.cmd("LIMIT abc"); i = i and "ERR" in o
    o = t.cmd("PLUG ON NOW"); i = i and "ERR" in o and not b().plug_on()
    t.check("terminal", "bad_arguments_give_err", i)
    t.boot(); o = t.cmd(""); i = "ERR" not in o; o = t.cmd("   "); i = i and "ERR" not in o
    t.check("terminal", "blank_line_is_ignored", i)
    t.boot(); b().type("X" * 2000, gap_ms=0); t.run(400); b().type("\r"); t.run(50); t.out(); t.cmd("LAMP ON")
    t.check("terminal", "survives_overlong_line", b().lamp_on())
    # help and status
    t.boot(); o = t.cmd("HELP")
    t.check("status", "help_lists_commands", all(w in o for w in ("LAMP", "PLUG", "LIMIT", "STATUS", "LOG", "HELP")))
    t.boot(); t.cmd("LAMP ON"); t.cmd("PLUG ON"); b().set_door_open(True); b().set_temp_deci(228); t.run(100)
    o = t.cmd("STATUS")
    t.check("status", "status_lamp", has(o, "LAMP ON\n")); t.check("status", "status_plug", has(o, "PLUG ON\n"))
    t.check("status", "status_door", has(o, "DOOR OPEN\n")); t.check("status", "status_temp", t.temp_is(o, 22.8))
    t.check("status", "status_alarm", has(o, "ALARM OFF\n"))
    if t.b:
        for k, v in t.b.diag.items(): t.diag.setdefault(k, v)
    for k, (msg, n) in t.diag.items(): print(f"DIAG {k} x{n}: {msg}")
    print(f"SUMMARY failed={t.failed}")
    return t

HW_DIAG = re.compile(r"^(gpio.-noclk|uart-baud|uart-frame|uart-pin-.*|uart-noclk|uart-tx-off|adc-noclk|adc-pin|adc-den|timer.-noclk|crash)$")

def main(path, out_json=None):
    checks, image, failed, tests = [], None, 0, []
    def add(title, ok, hint=""): checks.append({"title": title, "ok": bool(ok), "skipped": False, "hint": hint})
    if os.path.isdir(path):
        c = find_image.candidates(path)
        image = c[0] if c else None
        if not image:
            print("NOIMAGE no firmware image (.out / .elf) found in the project folder")
    else: image = path
    if image:
        ok, msg = find_image.inspect(image)
        print("IMAGE", os.path.relpath(image, path) if os.path.isdir(path) else image)
        add("The firmware image (.out/.elf) is in the project and contains the HAL and app functions", ok, msg)
        if ok:
            import io, contextlib
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                try: t = run_all(image, quiet=True)
                except Exception as e: t = None; print(f"EMUERROR {e}")
            sys.stdout.write(buf.getvalue())
            if t is not None:
                failed = t.failed
                tests = re.findall(r"^TEST (\S+) (\S+) (PASS|FAIL)$", buf.getvalue(), re.M)
                crash = [m for k, (m, n) in t.diag.items() if k == "crash"]
                add("The firmware runs on the board without crashing", not crash, crash[0] if crash else "")
                bad = [m for k, (m, n) in t.diag.items() if HW_DIAG.match(k)]
                add("The peripherals are configured correctly (clocks, UART 115200 8N1 on PA0/PA1, analog pin)", not bad,
                    "; ".join(bad[:2]))
            else:
                add("The firmware runs on the board without crashing", False, "the emulator could not run it")
    else:
        add("The firmware image (.out/.elf) is in the project and contains the HAL and app functions", False,
            "build the project in IAR and zip the whole project folder including the Debug/Exe/*.out file")
    if out_json:
        json.dump({"image": image and os.path.basename(image), "checks": checks, "tests": tests}, open(out_json, "w"), indent=1)
    return failed

if __name__ == "__main__":
    sys.exit(1 if main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None) else 0)
