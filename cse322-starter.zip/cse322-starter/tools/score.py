#!/usr/bin/env python3
"""Turns the test log into results.json and a marks summary.
Usage: python3 tools/score.py test.log [results.json]   (always exits 0)"""
import json, re, sys, collections

# group -> (rubric item, marks).  Door log, app UI and mounting are marked from the demo video.
RUBRIC = {"lamp": ("Lamp control (board side)", 3), "plug": ("Plug control (board side)", 2),
          "door": ("Door status (board side)", 2), "temp": ("Temperature display (board side)", 2),
          "alarm": ("Temperature alarm (board side)", 2), "bluetooth": ("Bluetooth communication", 2)}

log = open(sys.argv[1], errors="replace").read() if len(sys.argv) > 1 else ""
out = sys.argv[2] if len(sys.argv) > 2 else "results.json"
res = collections.defaultdict(list)
for g, n, s in re.findall(r"^TEST (\S+) (\S+) (PASS|FAIL)$", log, re.M):
    res[g].append((n, s == "PASS"))

total = got = 0.0
items = {}
for g, (title, marks) in RUBRIC.items():
    t = res.get(g, [])
    frac = sum(ok for _, ok in t) / len(t) if t else 0.0
    items[g] = {"item": title, "marks": marks, "earned": round(marks * frac, 2),
                "passed": sum(ok for _, ok in t), "tests": len(t),
                "failing": [n for n, ok in t if not ok]}
    total += marks; got += marks * frac
json.dump({"automated_marks": round(got, 2), "automated_out_of": total, "items": items},
          open(out, "w"), indent=2)

print(f"{'Item':36} {'Tests':>7} {'Marks':>9}")
for it in items.values():
    print(f"{it['item']:36} {it['passed']:>3}/{it['tests']:<3} {it['earned']:>4}/{it['marks']}")
    for n in it["failing"]: print(f"    failing: {n}")
print(f"{'Automated total':36} {'':>7} {got:>4.1f}/{total:.0f}")
print("Note: app UI, door log, mounting and report are marked from the video and report.")
