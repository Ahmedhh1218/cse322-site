#!/usr/bin/env python3
"""Static checks of the MCAL and HAL layers (what the simulated-board tests cannot see).
Usage: check_hw.py [ROOT] [out.json]
The checks catch stubs and missing drivers. They cannot know whether your pin numbers are right:
that is what the demo video shows."""
import json, os, re, shutil, subprocess, sys

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else "."
OUT = sys.argv[2] if len(sys.argv) > 2 else None
FW = os.path.join(ROOT, "firmware")

def files(d, exts=(".c",)):
    out = []
    for base, _, fs in os.walk(os.path.join(FW, d)):
        out += [os.path.join(base, f) for f in sorted(fs) if f.endswith(exts)]
    return out
def strip(t):
    t = re.sub(r"/\*.*?\*/", " ", t, flags=re.S)
    t = re.sub(r"//[^\n]*", " ", t)
    return re.sub(r'"(?:\\.|[^"\\])*"', '""', t)
def code(fs): return "\n".join(strip(open(f, encoding="utf-8", errors="replace").read()) for f in fs)
def code_lines(fs): return sum(1 for l in code(fs).splitlines() if l.strip() and not l.strip().startswith("#include"))

# Everything under firmware/ except the app layer counts: teams may organise MCAL and HAL files as they like.
other_dirs = [d for d in sorted(os.listdir(FW)) if os.path.isdir(os.path.join(FW, d)) and d != "app"] if os.path.isdir(FW) else []
hw_c = []
for d in other_dirs: hw_c += files(d)
main_c = [os.path.join(FW, "main.c")] if os.path.isfile(os.path.join(FW, "main.c")) else []
mcal_c, hal_c = files("mcal"), files("hal")
hw = code(hw_c)
checks = []
def add(title, ok, hint="", skipped=False): checks.append({"title": title, "ok": bool(ok), "skipped": skipped, "hint": hint})

HAL_FUNCS = ["Lamp_Init", "Lamp_Set", "Plug_Init", "Plug_Set", "Door_Init", "Door_IsOpen", "Lm35_Init", "Lm35_ReadDeciC",
             "Serial_Init", "Serial_Read", "Serial_Write", "Time_Init", "Time_Millis"]
missing = [f for f in HAL_FUNCS if not re.search(r"\b%s\s*\([^;{)]*\)\s*\{" % f, hw)]
add("The 13 functions of the six HAL headers are implemented (in any file outside app/)", not missing,
    "missing: " + ", ".join(missing) if missing else "")
add("GPIO is configured (registers or TivaWare)", re.search(r"GPIO|0x4000[4-7]000|0x4002[4-7]000", hw) is not None)
add("The ADC is configured", re.search(r"\bADC|0x4003[89]000", hw) is not None)
add("UART0 (USB virtual COM port) is configured", re.search(r"UART0|0x4000[Cc]000", hw) is not None)
add("SysTick (or another timer) is configured", re.search(r"NVIC_ST|SysTick|SYSTICK|0xE000E010|TIMER[0-9]|WTIMER", hw, re.I) is not None)

# Cross-compile: syntax and type check for the real target. Vendor headers that are not in the zip are skipped.
gcc = shutil.which("arm-none-eabi-gcc")
if not gcc:
    add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", True, "compiler not available here", skipped=True)
elif code_lines(hw_c) < 30:
    add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", False, "the MCAL and HAL are still (nearly) empty")
else:
    srcs = hw_c + main_c
    inc_dirs = [FW] + [b for b, _, _ in os.walk(FW)]
    bad, noheader = [], 0
    for f in srcs:
        r = subprocess.run([gcc, "-mcpu=cortex-m4", "-mthumb", "-ffreestanding", "-fsyntax-only", "-w",
                            *[x for d in inc_dirs for x in ("-I", d)], "-I", os.path.dirname(f), f],
                           capture_output=True, text=True, timeout=60)
        if r.returncode:
            if re.search(r"fatal error: .*No such file or directory", r.stderr): noheader += 1
            else:
                first = next((l for l in r.stderr.splitlines() if "error" in l), r.stderr[:120])
                bad.append(os.path.relpath(f, ROOT) + ": " + first.split(ROOT + os.sep)[-1][:140])
    if bad: add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", False, "; ".join(bad[:3]))
    elif noheader == len(srcs): add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", True,
                                    "vendor header not included in the zip, compile not verified", skipped=True)
    else: add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", True,
              "%d file(s) use headers that are not in the zip (not checked)" % noheader if noheader else "")

counted = [c for c in checks if not c["skipped"]]
res = {"passed": sum(c["ok"] for c in counted), "total": len(counted), "checks": checks}
if OUT: json.dump(res, open(OUT, "w"), indent=2)
for c in checks:
    print(("SKIP" if c["skipped"] else "ok  " if c["ok"] else "FAIL"), c["title"], ("- " + c["hint"]) if c["hint"] else "")
print("HARDWARE CHECK: %d/%d" % (res["passed"], res["total"]))
