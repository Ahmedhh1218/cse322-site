#!/usr/bin/env python3
"""Static checks of the MCAL and HAL layers (what the simulated-board tests cannot see).
Usage: check_hw.py [ROOT] [out.json]
The checks catch stubs and missing drivers. They cannot know whether your pin numbers are right:
that is what the demo video shows."""
import json, os, re, shutil, subprocess, sys

ROOT = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else "."
OUT = sys.argv[2] if len(sys.argv) > 2 else None
FW = os.path.join(ROOT, "firmware")

def files(d, exts=(".c",)):
    out = []
    for base, _, fs in os.walk(os.path.join(FW, d)):
        out += [os.path.join(base, f) for f in sorted(fs) if f.endswith(exts)]
    return out
def strip(t):
    t = re.sub(r"/\*.*?\*/", " ", t, flags=re.S)
    t = re.sub(r"//[^\n]*", " ", t)
    return re.sub(r'"(?:\\.|[^"\\])*"', '""', t)
def code(fs): return "\n".join(strip(open(f, encoding="utf-8", errors="replace").read()) for f in fs)
def code_lines(fs): return sum(1 for l in code(fs).splitlines() if l.strip() and not l.strip().startswith("#include"))

mcal_c, hal_c = files("mcal"), files("hal")
mcal, hal = code(mcal_c), code(hal_c)
checks = []
def add(title, ok, hint="", skipped=False): checks.append({"title": title, "ok": bool(ok), "skipped": skipped, "hint": hint})

HAL_MODULES = {"lamp": ["Lamp_Init", "Lamp_Set"], "plug": ["Plug_Init", "Plug_Set"], "door": ["Door_Init", "Door_IsOpen"],
               "lm35": ["Lm35_Init", "Lm35_ReadDeciC"], "serial": ["Serial_Init", "Serial_Read", "Serial_Write"],
               "timebase": ["Time_Init", "Time_Millis"]}
missing = [f for fns in HAL_MODULES.values() for f in fns if not re.search(r"\b%s\s*\([^;{)]*\)\s*\{" % f, hal)]
add("The HAL implements all 13 functions of the six device headers", not missing,
    "missing: " + ", ".join(missing) if missing else "")

# One module per device: lamp.h has lamp.c, and so on (each .c must define that device's functions).
bad_mod = []
for mod, fns in HAL_MODULES.items():
    cands = [f for f in hal_c if os.path.splitext(os.path.basename(f))[0] == mod]
    if not cands or not all(re.search(r"\b%s\s*\([^;{)]*\)\s*\{" % fn, code(cands)) for fn in fns): bad_mod.append(mod)
add("HAL is split into one .c per device (lamp.c, plug.c, door.c, lm35.c, serial.c, timebase.c)", not bad_mod,
    "check: " + ", ".join(m + ".c" for m in bad_mod) if bad_mod else "")

KW = {"if", "while", "for", "switch", "return", "sizeof"}
mcal_funcs = {m for m in re.findall(r"^[ \t]*(?!static\b)[A-Za-z_][\w \t\*]*?\b([A-Za-z_]\w*)\s*\([^;{)]*\)\s*\{", mcal, re.M) if m not in KW}
used = sorted(n for n in mcal_funcs if re.search(r"\b%s\s*\(" % re.escape(n), hal))
tiva = re.findall(r"\b(?:GPIO|SysCtl|ADC|UART|SysTick)[A-Za-z0-9]*\s*\(", hal)
add("The HAL calls MCAL driver functions or TivaWare (at least 3 calls)", len(used) + len(set(tiva)) >= 3,
    "found %d MCAL functions and %d TivaWare calls used from the HAL" % (len(used), len(set(tiva))))
add("MCAL is split into several driver modules (e.g. DIO, UART, ADC) or uses TivaWare",
    len(mcal_c) >= 3 or re.search(r"driverlib/|GPIOPin|SysCtl|ADCSequence|UARTConfig", mcal + hal) is not None,
    "%d .c files in firmware/mcal" % len(mcal_c))

both = mcal + "\n" + hal       # TivaWare users may call the library from thin wrappers in either layer
add("GPIO is configured (registers or TivaWare)", re.search(r"GPIO|0x4000[4-7]000|0x4002[4-7]000", both) is not None)
add("The ADC is configured", re.search(r"\bADC|0x4003[89]000", both) is not None)
add("UART0 (USB virtual COM port) is configured", re.search(r"UART0|0x4000[Cc]000", both) is not None)
add("SysTick (or another timer) is configured", re.search(r"NVIC_ST|SysTick|SYSTICK|0xE000E010|TIMER[0-9]|WTIMER", both, re.I) is not None)

# Cross-compile: syntax and type check for the real target. Vendor headers that are not in the zip are skipped.
gcc = shutil.which("arm-none-eabi-gcc")
if not gcc:
    add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", True, "compiler not available here", skipped=True)
elif code_lines(mcal_c) < 15 or code_lines(hal_c) < 15:
    add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", False, "mcal/ and hal/ are still (nearly) empty")
else:
    srcs = files("mcal") + files("hal") + [f for f in [os.path.join(FW, "main.c")] if os.path.isfile(f)]
    bad, noheader = [], 0
    for f in srcs:
        r = subprocess.run([gcc, "-mcpu=cortex-m4", "-mthumb", "-ffreestanding", "-fsyntax-only", "-w",
                            "-I", FW, "-I", os.path.join(FW, "mcal"), "-I", os.path.join(FW, "hal"),
                            "-I", os.path.join(FW, "app"), "-I", os.path.dirname(f), f],
                           capture_output=True, text=True, timeout=60)
        if r.returncode:
            if re.search(r"fatal error: .*No such file or directory", r.stderr): noheader += 1
            else:
                first = next((l for l in r.stderr.splitlines() if "error" in l), r.stderr[:120])
                bad.append(os.path.relpath(f, ROOT) + ": " + first.split(ROOT + os.sep)[-1][:140])
    if bad: add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", False, "; ".join(bad[:3]))
    elif noheader == len(srcs): add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", True,
                                    "vendor header not included in the zip, compile not verified", skipped=True)
    else: add("Firmware compiles for the TM4C123 (arm-none-eabi-gcc)", True,
              "%d file(s) use headers that are not in the zip (not checked)" % noheader if noheader else "")

counted = [c for c in checks if not c["skipped"]]
res = {"passed": sum(c["ok"] for c in counted), "total": len(counted), "checks": checks}
if OUT: json.dump(res, open(OUT, "w"), indent=2)
for c in checks:
    print(("SKIP" if c["skipped"] else "ok  " if c["ok"] else "FAIL"), c["title"], ("- " + c["hint"]) if c["hint"] else "")
print("HARDWARE CHECK: %d/%d" % (res["passed"], res["total"]))
