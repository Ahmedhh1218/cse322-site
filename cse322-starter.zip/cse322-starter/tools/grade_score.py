#!/usr/bin/env python3
"""Turns the test log and the check results into marks.
Usage: grade_score.py test.log hw.json report.json structure.json rubric.json out.json"""
import json, re, sys, collections

log_p, hw_p, rep_p, st_p, rub_p, out_p = sys.argv[1:7]
log = open(log_p, errors="replace").read() if log_p != "-" else ""
rub = json.load(open(rub_p))
def load(p, default): 
    try: return json.load(open(p))
    except Exception: return default
hw = load(hw_p, {"passed": 0, "total": 0, "checks": []})
rep = load(rep_p, {"passed": 0, "total": 0, "checks": []})
st = load(st_p, {"layers_ok": False})

board = collections.defaultdict(list)
for g, n, s in re.findall(r"^TEST (\S+) (\S+) (PASS|FAIL)$", log, re.M):
    board[g].append((n, s == "PASS"))

def empty_checks(): return {"passed": 0, "total": 0, "missing": []}
items, got, total = {}, 0.0, 0.0
def add(key, r, earned, board_=None, checks=None, extra=None):
    global got, total
    items[key] = {"item": r["item"], "marks": r["marks"], "earned": round(earned, 2),
                  "board": board_ or {"passed": 0, "tests": 0, "failing": []}, "checks": checks or empty_checks(), **(extra or {})}
    got += earned; total += r["marks"]

# A stub app can pass "nothing happens" tests by accident, so tests only count once the app layer has real code.
app_has_code = st.get("layer_code_lines", {}).get("app", 0) >= 10
for key, r in rub["functional"].items():
    t = board.get(key, [])
    frac = sum(ok for _, ok in t) / len(t) if t and app_has_code else 0.0
    add(key, r, r["marks"] * frac, {"passed": sum(ok for _, ok in t), "tests": len(t), "failing": [n for n, ok in t if not ok]})

def from_checks(res, r):
    counted = [c for c in res["checks"] if not c.get("skipped")]
    frac = res["passed"] / res["total"] if res["total"] else 0.0
    return r["marks"] * frac, {"passed": res["passed"], "total": res["total"],
                               "missing": [c["title"] + (" (" + c["hint"] + ")" if c.get("hint") else "") for c in counted if not c["ok"]]}
e, c = from_checks(hw, rub["hardware"]); add("hardware", rub["hardware"], e, checks=c)
a = rub["architecture"]
add("architecture", a, a["marks"] if st.get("layers_ok") else 0, extra={"layer_code_lines": st.get("layer_code_lines", {})})
e, c = from_checks(rep, rub["report"]); add("report", rub["report"], e, checks=c)

json.dump({"automated_marks": round(got, 2), "automated_out_of": total, "items": items, "manual_items": []},
          open(out_p, "w"), indent=2)

print(f"{'Item':34} {'Tests':>7} {'Checks':>7} {'Marks':>9}")
for it in items.values():
    b = f"{it['board']['passed']}/{it['board']['tests']}" if it["board"]["tests"] else "-"
    ck = f"{it['checks']['passed']}/{it['checks']['total']}" if it["checks"]["total"] else "-"
    print(f"{it['item']:34} {b:>7} {ck:>7} {it['earned']:>5}/{it['marks']}")
print(f"{'Total':34} {'':>7} {'':>7} {got:>5.1f}/{total:.0f}")
