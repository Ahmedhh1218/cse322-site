#!/usr/bin/env python3
"""Turns the test log and the check results into marks.
Usage: grade_score.py test.log hw.json report.json structure.json rubric.json out.json [emu.log emu.json [app.json]]
Board part of a functional item = the lower share of the host tests (your source) and the emulator tests (your built image).
App part = share of the mobile-app checks (tools/check_app.py) that pass."""
import json, re, sys, collections

log_p, hw_p, rep_p, st_p, rub_p, out_p = sys.argv[1:7]
emu_log_p = sys.argv[7] if len(sys.argv) > 7 else "-"
emu_json_p = sys.argv[8] if len(sys.argv) > 8 else "-"
app_json_p = sys.argv[9] if len(sys.argv) > 9 else "-"
log = open(log_p, errors="replace").read() if log_p != "-" else ""
rub = json.load(open(rub_p))
def load(p, default): 
    try: return json.load(open(p))
    except Exception: return default
hw = load(hw_p, {"passed": 0, "total": 0, "checks": []})
rep = load(rep_p, {"passed": 0, "total": 0, "checks": []})
st = load(st_p, {"layers_ok": False})
emu_on = emu_log_p != "-"
emu_log = open(emu_log_p, errors="replace").read() if emu_on else ""
emu = load(emu_json_p, {"checks": []})
app = load(app_json_p, {"kind": "none", "note": "", "groups": {}})
hw = {"passed": hw["passed"] + sum(1 for c in emu["checks"] if c["ok"]), "total": hw["total"] + len(emu["checks"]),
      "checks": hw["checks"] + emu["checks"]}

board = collections.defaultdict(list)
for g, n, s in re.findall(r"^TEST (\S+) (\S+) (PASS|FAIL)$", log, re.M):
    board[g].append((n, s == "PASS"))
eboard = collections.defaultdict(list)
for g, n, s in re.findall(r"^TEST (\S+) (\S+) (PASS|FAIL)$", emu_log, re.M):
    eboard[g].append((n, s == "PASS"))

def empty_checks(): return {"passed": 0, "total": 0, "missing": []}
items, got, total = {}, 0.0, 0.0
def add(key, r, earned, board_=None, checks=None, extra=None):
    global got, total
    items[key] = {"item": r["item"], "marks": r["marks"], "earned": round(earned, 2),
                  "board": board_ or {"passed": 0, "tests": 0, "failing": []}, "checks": checks or empty_checks(), **(extra or {})}
    got += earned; total += r["marks"]

# A stub app can pass "nothing happens" tests by accident, so tests only count once the app layer has real code.
app_has_code = st.get("layer_code_lines", {}).get("app", 0) >= 10
for key, r in rub["functional"].items():
    wb, wa = r.get("board", 1.0), r.get("app", 0.0)
    t = board.get(key, []); et = eboard.get(key, [])
    frac = sum(ok for _, ok in t) / len(t) if t and app_has_code else 0.0
    efrac = sum(ok for _, ok in et) / len(et) if et else 0.0
    if emu_on: frac = min(frac, efrac)
    failing = [n for n, ok in t if not ok] + ["image: " + n for n, ok in et if not ok]
    if emu_on and not et and wb: failing.append("image: no firmware image could be run")
    g = app["groups"].get(key, {"passed": 0, "total": 0, "checks": []})
    afrac = g["passed"] / g["total"] if g["total"] else 0.0
    missing = [c["title"] for c in g["checks"] if not c["ok"]] if g["total"] else ["no mobile app found" if app["kind"] == "none" else "nothing to check"]
    extra = {"app": {"passed": g["passed"], "total": g["total"], "missing": missing, "weight": wa}, "board_weight": wb}
    if emu_on: extra["image_tests"] = {"passed": sum(ok for _, ok in et), "tests": len(et)}
    add(key, r, r["marks"] * (wb * frac + wa * afrac), {"passed": sum(ok for _, ok in t), "tests": len(t), "failing": failing}, extra=extra)

def from_checks(res, r):
    counted = [c for c in res["checks"] if not c.get("skipped")]
    frac = res["passed"] / res["total"] if res["total"] else 0.0
    return r["marks"] * frac, {"passed": res["passed"], "total": res["total"],
                               "missing": [c["title"] + (" (" + c["hint"] + ")" if c.get("hint") else "") for c in counted if not c["ok"]]}
e, c = from_checks(hw, rub["hardware"]); add("hardware", rub["hardware"], e, checks=c)
a = rub["architecture"]
add("architecture", a, a["marks"] if st.get("layers_ok") else 0, extra={"layer_code_lines": st.get("layer_code_lines", {})})
e, c = from_checks(rep, rub["report"]); add("report", rub["report"], e, checks=c)

json.dump({"automated_marks": round(got, 2), "automated_out_of": total, "items": items, "manual_items": [],
           "app_check": {"kind": app["kind"], "note": app["note"]}},
          open(out_p, "w"), indent=2)

print(f"{'Item':34} {'Tests':>7} {'Checks':>7} {'Marks':>9}")
for it in items.values():
    b = f"{it['board']['passed']}/{it['board']['tests']}" if it["board"]["tests"] else "-"
    ck = f"{it['checks']['passed']}/{it['checks']['total']}" if it["checks"]["total"] else (f"app {it['app']['passed']}/{it['app']['total']}" if it.get("app", {}).get("total") else "-")
    print(f"{it['item']:34} {b:>7} {ck:>7} {it['earned']:>5}/{it['marks']}")
print(f"{'Total':34} {'':>7} {'':>7} {got:>5.1f}/{total:.0f}")
