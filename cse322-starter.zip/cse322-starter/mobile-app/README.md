Put your mobile app project here.
App Inventor: Projects > Export selected project (.aia) and save the file in this folder (source only, no APK needed).
Any other framework: put the source code here.
