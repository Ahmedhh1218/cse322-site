Put your mobile app project here (source only, no build output).
Add a line below with the APK / build name if you have one.
