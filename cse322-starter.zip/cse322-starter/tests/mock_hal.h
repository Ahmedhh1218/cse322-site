#ifndef MOCK_HAL_H
#define MOCK_HAL_H
#include <stdint.h>
void  mock_reset(void);
void  mock_rx(const char *s);          /* bytes the "phone" sends to the board  */
const char *mock_tx_take(void);        /* everything the board sent; clears it  */
void  mock_advance(uint32_t ms);
void  mock_set_temp(int deci_c);
void  mock_set_door_open(int open);
int   mock_lamp(void);
int   mock_plug(void);
#endif
