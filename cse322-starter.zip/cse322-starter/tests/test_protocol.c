/* Automated conformance tests for the Home Appliances project (PuTTY terminal protocol).
 * The tests type into the board like a person at a PuTTY window: Enter sends CR,
 * and everything the board writes is read back from the simulated UART.
 * Output lines:  TEST <group> <name> PASS|FAIL   (read by the grader) */
#include <stdio.h>
#include <string.h>
#include "app.h"
#include "mock_hal.h"

static int failed;
static void check(const char *group, const char *name, int ok)
{
    printf("TEST %s %s %s\n", group, name, ok ? "PASS" : "FAIL");
    if (!ok) failed++;
}
static void boot(void){ mock_reset(); mock_tx_take(); App_Init(); }
/* run the app for ms milliseconds, 10 ms steps */
static void run(uint32_t ms){ while (ms >= 10) { mock_advance(10); App_Update(); ms -= 10; } }
/* put bytes on the UART and let the app run once per byte (works for one-byte-per-update designs) */
static void type(const char *s){ mock_rx(s); { size_t n = strlen(s) + 3; while (n--) App_Update(); } }

static char raw[8192], norm[8192];
/* Type a command, then press Enter. Returns what the board sent after Enter, with CRs removed
 * (raw bytes stay in `raw`). Anything sent while typing, i.e. the echo, is discarded. */
static const char *cmd_end(const char *text, const char *enter)
{
    const char *o; char *d = norm; const char *s;
    type(text); mock_tx_take();
    type(enter); o = mock_tx_take();
    strncpy(raw, o, sizeof raw - 1); raw[sizeof raw - 1] = 0;
    for (s = o; *s; s++) if (*s != '\r') *d++ = *s;
    *d = 0; return norm;
}
static const char *cmd(const char *text){ return cmd_end(text, "\r"); }
static int has(const char *hay, const char *needle){ return strstr(hay, needle) != NULL; }
static int count(const char *hay, const char *needle){ int c=0; const char*p=hay; while((p=strstr(p,needle))){c++;p+=strlen(needle);} return c; }
static void drop_cr(const char *o){ char *d = norm; for (; *o; o++) if (*o != '\r') *d++ = *o; *d = 0; }

int main(void)
{
    const char *o; int i;

    /* ---- lamp ---- */
    boot(); o = cmd("LAMP ON");
    check("lamp","on_drives_relay", mock_lamp()==1);
    check("lamp","on_reply", has(o,"LAMP ON\n"));
    o = cmd("LAMP OFF");
    check("lamp","off_drives_relay", mock_lamp()==0);
    check("lamp","off_reply", has(o,"LAMP OFF\n"));
    check("lamp","plug_untouched", mock_plug()==0);

    /* ---- plug ---- */
    boot(); o = cmd("PLUG ON");
    check("plug","on_drives_relay", mock_plug()==1);
    check("plug","on_reply", has(o,"PLUG ON\n"));
    o = cmd("PLUG OFF");
    check("plug","off_drives_relay", mock_plug()==0);
    check("plug","off_reply", has(o,"PLUG OFF\n"));
    check("plug","lamp_untouched", mock_lamp()==0);

    /* ---- door ---- */
    boot(); run(100); mock_tx_take();
    mock_set_door_open(1); run(100); drop_cr(mock_tx_take()); o = norm;
    check("door","open_reported", count(o,"DOOR OPEN\n")==1);
    mock_set_door_open(0); run(100); drop_cr(mock_tx_take()); o = norm;
    check("door","closed_reported", count(o,"DOOR CLOSED\n")==1);
    run(500); drop_cr(mock_tx_take()); o = norm;
    check("door","no_repeat_without_change", !has(o,"DOOR "));

    /* ---- temperature ---- */
    boot(); mock_set_temp(275); run(990); drop_cr(mock_tx_take()); o = norm;
    check("temp","not_before_1s", !has(o,"TEMP "));
    run(30); drop_cr(mock_tx_take()); o = norm;
    check("temp","sent_after_1s", has(o,"TEMP 27.5\n"));
    mock_set_temp(301); run(1000); drop_cr(mock_tx_take()); o = norm;
    check("temp","follows_sensor", has(o,"TEMP 30.1\n"));
    run(3000); drop_cr(mock_tx_take()); o = norm;
    check("temp","once_per_second", count(o,"TEMP ")==3);

    /* ---- alarm ---- */
    boot(); mock_set_temp(250); o = cmd("LIMIT 30");
    check("alarm","limit_reply", has(o,"LIMIT 30\n"));
    run(1500); drop_cr(mock_tx_take()); o = norm;
    check("alarm","quiet_below_limit", !has(o,"ALARM ON"));
    mock_set_temp(305); run(1100); drop_cr(mock_tx_take()); o = norm;
    check("alarm","raised_above_limit", count(o,"ALARM ON\n")==1);
    run(3000); drop_cr(mock_tx_take()); o = norm;
    check("alarm","sent_once_per_transition", !has(o,"ALARM "));
    mock_set_temp(300); run(1100); drop_cr(mock_tx_take()); o = norm;
    check("alarm","cleared_at_limit", count(o,"ALARM OFF\n")==1);
    type("LIMIT 20\r"); run(1100); drop_cr(mock_tx_take()); o = norm;
    check("alarm","new_limit_applies", has(o,"ALARM ON\n"));

    /* ---- door log ---- */
    boot(); o = cmd("LOG");
    check("doorlog","empty_log", has(o,"LOG EMPTY"));
    boot(); run(2050); mock_set_door_open(1); run(100); run(2900); mock_set_door_open(0); run(100);
    o = cmd("LOG");
    check("doorlog","records_open_and_close_times",
          has(o,"LOG 2 OPEN\n") && has(o,"LOG 5 CLOSED\n") && strstr(o,"LOG 2 OPEN") < strstr(o,"LOG 5 CLOSED"));
    boot(); run(1050);
    for (i = 0; i < 8; i++) { mock_set_door_open(i % 2 == 0); run(100); run(900); }   /* events at 1..8 s */
    o = cmd("LOG");
    check("doorlog","keeps_last_five_only",
          count(o,"LOG ")==5 && !has(o,"LOG 3 OPEN") && has(o,"LOG 4 CLOSED\n") && has(o,"LOG 8 CLOSED\n"));

    /* ---- terminal behaviour ---- */
    boot(); type("LAM"); drop_cr(mock_tx_take()); o = norm;
    check("terminal","echoes_typed_characters", has(o,"LAM"));
    boot(); type("AB\x08"); o = mock_tx_take();
    check("terminal","backspace_is_echoed", strchr(o,'\b') != NULL || strchr(o,'\x7f') != NULL);
    boot(); cmd("LAMX\x08P ON");
    check("terminal","backspace_edits_the_line", mock_lamp()==1);
    boot(); cmd("LAMP ON");
    check("terminal","replies_end_with_crlf", has(raw,"LAMP ON\r\n") && count(raw,"\n")==count(raw,"\r\n"));
    boot(); cmd_end("LAMP ON","\n"); i = mock_lamp();
    cmd_end("LAMP OFF","\r\n"); i = i && !mock_lamp();
    cmd_end("LAMP ON","\r"); i = i && mock_lamp();
    check("terminal","enter_as_cr_lf_or_crlf", i);
    boot(); o = cmd_end("PLUG ON","\r\n");
    check("terminal","crlf_gives_no_error", !has(o,"ERR"));
    boot(); cmd("  lamp   on  ");
    check("terminal","case_and_spaces_ignored", mock_lamp()==1);
    boot(); mock_rx(""); { const char *s = "LAMP ON"; for (; *s; s++) { char c[2]; c[0]=*s; c[1]=0; type(c); } }
    type("\r");
    check("terminal","characters_one_at_a_time", mock_lamp()==1);
    boot(); type("LAMP ON\rPLUG ON\rLAMP OFF\r");
    check("terminal","several_commands_in_a_row", mock_lamp()==0 && mock_plug()==1);
    boot(); o = cmd("HELLO");
    check("terminal","unknown_command_gives_err", has(o,"ERR") && mock_lamp()==0 && mock_plug()==0);
    boot(); i = 1;
    o = cmd("LAMP 7");     i = i && has(o,"ERR") && mock_lamp()==0;
    o = cmd("LAMP");       i = i && has(o,"ERR");
    o = cmd("LIMIT abc");  i = i && has(o,"ERR");
    o = cmd("PLUG ON NOW");i = i && has(o,"ERR") && mock_plug()==0;
    check("terminal","bad_arguments_give_err", i);
    boot(); o = cmd(""); i = !has(o,"ERR"); o = cmd("   "); i = i && !has(o,"ERR");
    check("terminal","blank_line_is_ignored", i);
    boot(); { int k; for (k=0;k<200;k++) type("XXXXXXXXXX"); } type("\r"); mock_tx_take();
    cmd("LAMP ON");
    check("terminal","survives_overlong_line", mock_lamp()==1);

    /* ---- help and status ---- */
    boot(); o = cmd("HELP");
    check("status","help_lists_commands",
          has(o,"LAMP") && has(o,"PLUG") && has(o,"LIMIT") && has(o,"STATUS") && has(o,"LOG") && has(o,"HELP"));
    boot(); cmd("LAMP ON"); cmd("PLUG ON"); mock_set_door_open(1); mock_set_temp(228); run(100);
    o = cmd("STATUS");
    check("status","status_lamp", has(o,"LAMP ON\n"));
    check("status","status_plug", has(o,"PLUG ON\n"));
    check("status","status_door", has(o,"DOOR OPEN\n"));
    check("status","status_temp", has(o,"TEMP 22.8\n"));
    check("status","status_alarm", has(o,"ALARM OFF\n"));

    printf("SUMMARY failed=%d\n", failed);
    return failed ? 1 : 0;
}
