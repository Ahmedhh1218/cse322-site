/* Automated conformance tests for the Home Appliances project (Bluetooth protocol with the phone app).
 * The tests play the phone: they put text lines on the simulated HC-05 link and read back what the board sends.
 * Output lines:  TEST <group> <name> PASS|FAIL   (read by the grader) */
#include <stdio.h>
#include <string.h>
#include "app.h"
#include "mock_hal.h"

static int failed;
static void check(const char *group, const char *name, int ok)
{
    printf("TEST %s %s %s\n", group, name, ok ? "PASS" : "FAIL");
    if (!ok) failed++;
}
static void boot(void){ mock_reset(); mock_tx_take(); App_Init(); }
/* run the app for ms milliseconds, 10 ms steps */
static void run(uint32_t ms){ while (ms >= 10) { mock_advance(10); App_Update(); ms -= 10; } }
/* put bytes on the link and let the app run once per byte (also works for one-byte-per-update designs) */
static void send(const char *s){ size_t n = strlen(s) + 3; mock_rx(s); while (n--) App_Update(); }
static int has(const char *hay, const char *needle){ return strstr(hay, needle) != NULL; }
static int count(const char *hay, const char *needle){ int c=0; const char*p=hay; while((p=strstr(p,needle))){c++;p+=strlen(needle);} return c; }

int main(void)
{
    const char *o; int i;

    /* ---- lamp ---- */
    boot(); send("LAMP:1\n"); o = mock_tx_take();
    check("lamp","on_drives_relay", mock_lamp()==1);
    check("lamp","on_ack", has(o,"ACK:LAMP:1\n"));
    send("LAMP:0\n"); o = mock_tx_take();
    check("lamp","off_drives_relay", mock_lamp()==0);
    check("lamp","off_ack", has(o,"ACK:LAMP:0\n"));
    check("lamp","plug_untouched", mock_plug()==0);

    /* ---- plug ---- */
    boot(); send("PLUG:1\n"); o = mock_tx_take();
    check("plug","on_drives_relay", mock_plug()==1);
    check("plug","on_ack", has(o,"ACK:PLUG:1\n"));
    send("PLUG:0\n"); o = mock_tx_take();
    check("plug","off_drives_relay", mock_plug()==0);
    check("plug","off_ack", has(o,"ACK:PLUG:0\n"));
    check("plug","lamp_untouched", mock_lamp()==0);

    /* ---- door ---- */
    boot(); run(100); mock_tx_take();
    mock_set_door_open(1); run(100); o = mock_tx_take();
    check("door","open_reported", count(o,"DOOR:OPEN\n")==1);
    mock_set_door_open(0); run(100); o = mock_tx_take();
    check("door","closed_reported", count(o,"DOOR:CLOSED\n")==1);
    run(500); o = mock_tx_take();
    check("door","no_repeat_without_change", !has(o,"DOOR:"));

    /* ---- temperature ---- */
    boot(); mock_set_temp(275); run(990); o = mock_tx_take();
    check("temp","not_before_1s", !has(o,"TEMP:"));
    run(30); o = mock_tx_take();
    check("temp","sent_after_1s", has(o,"TEMP:27.5\n"));
    mock_set_temp(301); run(1000); o = mock_tx_take();
    check("temp","follows_sensor", has(o,"TEMP:30.1\n"));
    run(3000); o = mock_tx_take();
    check("temp","once_per_second", count(o,"TEMP:")==3);

    /* ---- alarm ---- */
    boot(); mock_set_temp(250); send("LIMIT:30\n"); o = mock_tx_take();
    check("alarm","limit_ack", has(o,"ACK:LIMIT:30\n"));
    run(1500); o = mock_tx_take();
    check("alarm","quiet_below_limit", !has(o,"ALARM:1"));
    mock_set_temp(305); run(1100); o = mock_tx_take();
    check("alarm","raised_above_limit", count(o,"ALARM:1\n")==1);
    run(3000); o = mock_tx_take();
    check("alarm","sent_once_per_transition", !has(o,"ALARM:"));
    mock_set_temp(300); run(1100); o = mock_tx_take();
    check("alarm","cleared_at_limit", count(o,"ALARM:0\n")==1);
    send("LIMIT:20\n"); run(1100); o = mock_tx_take();
    check("alarm","new_limit_applies", has(o,"ALARM:1\n"));

    /* ---- status and framing ---- */
    boot(); send("LAMP:1\n"); send("PLUG:1\n"); mock_set_door_open(1); mock_set_temp(228);
    run(100); mock_tx_take();
    send("STATUS?\n"); o = mock_tx_take();
    check("bluetooth","status_lamp", has(o,"LAMP:1\n"));
    check("bluetooth","status_plug", has(o,"PLUG:1\n"));
    check("bluetooth","status_door", has(o,"DOOR:OPEN\n"));
    check("bluetooth","status_temp", has(o,"TEMP:22.8\n"));
    check("bluetooth","status_alarm", has(o,"ALARM:0\n"));
    boot(); mock_rx("LAM"); App_Update(); send("P:1\r\n"); o = mock_tx_take();
    check("bluetooth","split_and_crlf", mock_lamp()==1 && has(o,"ACK:LAMP:1\n"));
    boot(); send("HELLO\n"); send("LAMP:7\n"); send("\n"); send("LIMIT:abc\n");
    o = mock_tx_take();
    check("bluetooth","bad_commands_ignored", mock_lamp()==0 && !has(o,"ACK"));
    boot(); send("LAMP:1\nPLUG:1\nLAMP:0\n"); o = mock_tx_take();
    check("bluetooth","several_commands_in_a_row", mock_lamp()==0 && mock_plug()==1 && count(o,"ACK:")==3);
    boot(); for (i = 0; i < 200; i++) send("XXXXXXXXXX");
    send("\nLAMP:1\n"); o = mock_tx_take();
    check("bluetooth","survives_overlong_line", mock_lamp()==1);

    printf("SUMMARY failed=%d\n", failed);
    return failed ? 1 : 0;
}
