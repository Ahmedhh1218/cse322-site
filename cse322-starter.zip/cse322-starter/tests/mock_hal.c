/* Simulated board: replaces every HAL .c file. Implements the six HAL headers. */
#include <string.h>
#include "lamp.h"
#include "plug.h"
#include "door.h"
#include "lm35.h"
#include "serial.h"
#include "timebase.h"
#include "mock_hal.h"

static char rx[4096]; static int rx_h, rx_t;
static char tx[8192]; static int tx_n;
static char taken[8192];
static uint32_t now; static int temp = 250, door_open, lamp, plug;

void mock_reset(void){ rx_h=rx_t=tx_n=0; tx[0]=0; now=0; temp=250; door_open=0; lamp=plug=0; }
void mock_rx(const char *s){ while(*s) rx[rx_t++ % 4096] = *s++; }
const char *mock_tx_take(void){ strcpy(taken, tx); tx_n=0; tx[0]=0; return taken; }
void mock_advance(uint32_t ms){ now += ms; }
void mock_set_temp(int d){ temp=d; }
void mock_set_door_open(int o){ door_open=o; }
int  mock_lamp(void){ return lamp; }
int  mock_plug(void){ return plug; }

void Lamp_Init(void){}
void Lamp_Set(int on){ lamp = on?1:0; }
void Plug_Init(void){}
void Plug_Set(int on){ plug = on?1:0; }
void Door_Init(void){}
int  Door_IsOpen(void){ return door_open; }
void Lm35_Init(void){}
int  Lm35_ReadDeciC(void){ return temp; }
void Serial_Init(void){}
int  Serial_Read(void){ return rx_h==rx_t ? -1 : (unsigned char)rx[rx_h++ % 4096]; }
void Serial_Write(const char *s){ int n=(int)strlen(s); if(tx_n+n<8191){ memcpy(tx+tx_n,s,n+1); tx_n+=n; } }
void Time_Init(void){}
uint32_t Time_Millis(void){ return now; }
