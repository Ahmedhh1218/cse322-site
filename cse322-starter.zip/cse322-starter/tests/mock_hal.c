#include <string.h>
#include "hal.h"
#include "mock_hal.h"

static char rx[4096]; static int rx_h, rx_t;
static char tx[8192]; static int tx_n;
static char taken[8192];
static uint32_t now; static int temp = 250, door_open, lamp, plug;

void mock_reset(void){ rx_h=rx_t=tx_n=0; tx[0]=0; now=0; temp=250; door_open=0; lamp=plug=0; }
void mock_rx(const char *s){ while(*s) rx[rx_t++ % 4096] = *s++; }
const char *mock_tx_take(void){ strcpy(taken, tx); tx_n=0; tx[0]=0; return taken; }
void mock_advance(uint32_t ms){ now += ms; }
void mock_set_temp(int d){ temp=d; }
void mock_set_door_open(int o){ door_open=o; }
int  mock_lamp(void){ return lamp; }
int  mock_plug(void){ return plug; }

void Hal_Init(void){}
void Hal_LampSet(int on){ lamp = on?1:0; }
void Hal_PlugSet(int on){ plug = on?1:0; }
int  Hal_DoorIsOpen(void){ return door_open; }
int  Hal_TempReadDeciC(void){ return temp; }
int  Hal_UartRead(void){ return rx_h==rx_t ? -1 : (unsigned char)rx[rx_h++ % 4096]; }
void Hal_UartWrite(const char *s){ int n=(int)strlen(s); if(tx_n+n<8191){ memcpy(tx+tx_n,s,n+1); tx_n+=n; } }
uint32_t Hal_Millis(void){ return now; }
